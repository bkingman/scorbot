/*
 * File:   Config_PDCP_Unit_Commands.c
 * Author: yveslosier
 *
 * Created on February 19, 2014, 12:10 AM
 */


#include "Config_PDCP_Unit_Commands.h"

//---------------------------------------------------------------------------
// Functions related to General function calls used by PDCP library
//   These functions are used to provide a layer of abstraction to the
//   PDCP library
//---------------------------------------------------------------------------

void SEND_PDCP_MESSAGE_TO_HARDWARE_QUEUE(PDCPMESSAGE * PDCPMessage)
{
    ADD_PDCP_MESSAGE_TO_CAN_TX_QUEUE(PDCPMessage);
}


unsigned char PDCP_MESSAGE_AVAILABLE_FROM_HARDWARE_QUEUE(void)
{
    return ((headCanRxMessageList[0]!=NULL_POINTER)||(headCanRxMessageList[1]!=NULL_POINTER)||(headCanRxMessageList[2]!=NULL_POINTER));
}


unsigned char RETRIEVE_PDCP_MESSAGE_FROM_HARDWARE_QUEUE(PDCPMESSAGE * messageLocation)
{
    return GET_PDCP_MESSAGE_FROM_CAN_RX_QUEUE(messageLocation);
}


void UPDATE_PDCP_HARDWARE_STATE_MACHINES(void)
{
    UpdateCAN1RxStateMachine();
    UpdateCAN1TxStateMachine();
}


void PDCP_COMMAND_HARDWARE_CONFIG(void)
{
    ConfigCanHardware();
    InitCanMessageLists();
}


void ConfigHardwareMaskAndFilter(unsigned char nodeId, unsigned char boundFlag)
{
    if (boundFlag == 0)
    {
        ecan1init((0x300 + nodeId),CAN1_BINDING_MASK);
    }
    else
    {
        ecan1init((0x000 + nodeId),CAN1_OPEN_MASK);
    }
}


unsigned char MAX_DATA_PAYLOAD_PER_HARDWARE_MESSAGE(void)
{
    return CAN_MAX_DATA_PAYLOAD_PER_MESSAGE;
}

unsigned char MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE(void)
{
    return CAN_MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_SIZE;
}


unsigned char MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE(void)
{
    return CAN_MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_SIZE;
}


unsigned char MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_HARDWARE_SIZE(void)
{
    return CAN_MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_SIZE;
}

//---------------------------------------------------------------------------

