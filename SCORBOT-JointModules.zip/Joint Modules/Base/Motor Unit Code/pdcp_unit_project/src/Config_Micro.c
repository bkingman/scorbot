/*
 * File:   Config_Micro.c
 * Author: yveslosier
 *
 * Created on March 27, 2014, 8:50 PM
 */

#include "Config_Micro.h"
#include "OC.h"
#include "Timer2.h"

// Specify microprocessor-specific configuration registers
_FOSCSEL(FNOSC_PRI);
_FWDT(FWDTEN_OFF);
_FOSC(FCKSM_CSECMD & OSCIOFNC_ON & POSCMD_HS & IOL1WAY_OFF);
_FPOR(PWMPIN_ON); //PWM Module Pin Mode: PWM module pins controlled by PORT register at device reset
_FICD(JTAGEN_OFF & ICS_PGD1);


// Initialize microprocessor pins for CAN, I2C, and ADC modules
void CONFIG_MICRO(void)
{
    // Configure pin connected to Microstick II's onboard LED
    Config_LED1_Pin();
    Config_LED2_Pin();

    //Digital Output Pin Config
    _TRISB13 = 0;  // Motor Direction 1
    _TRISB12 = 0;  // Motor Direction 2
       
    // Limit Switch Pin
    _TRISA4 = 1;  // Digital Input Pin config
    
    
    
    
    // CAN RX Pin
    _TRISB6 = 1;  // input digital i/o

    // CAN TX Pin
    _TRISB7 = 0;  // output digital i/o

    // QEI Phase A Pin
    _TRISB8 = 1;  // output digital i/o
    
    // QEI Phase B Pin
    _TRISB9 = 1;  // output digital i/o

    //*************************************************************
    // Unlock Registers:
    //
    // Clear the bit 6 of OSCCONL to unlock Pin Re-map
    //
    //*************************************************************
    __builtin_write_OSCCONL(OSCCON & 0xbf);
    //*************************************************************

    _C1RXR = 6;  // CAN1 RX mapped onto RP6
    _RP7R  = 16; // CAN1 TX mapped onto RP7
    
    _QEA1R = 8;  // QEA1 mapped onto RP8
    _QEB1R = 9;  // QEB1 mapped onto RP9

    //************************************************************
    // Lock Registers:
    //
    // Set the bit 6 of OSCCONL to lock Pin Re-map
    //
    //************************************************************
    __builtin_write_OSCCONL(OSCCON | 0x40);
    //*************************************************************


    // CAN Transceiver Enable Pin
    _TRISB5 = 0;  // output digital i/o
    _LATB5  = 1;  // enable can transceiver


    // CAN Transceiver Standby Pin
    _TRISB4 = 0;  // output digital i/o
    _LATB4  = 0;  // set can transceiver in normal operation mode
    
    
    // Enable the QEI module (x4 mode with POSCNT reset by MAXCNT match)
    _QEIM = 0b111;

    //Digital filtering on the lines to help with any potential noise..... YGL
    DFLT1CONbits.QEOUT = 1;
    DFLT1CONbits.QECK = 7;
    
    
    
    /*
     *  //Init Homing 
     * 
     */
    IN1_OFF();
    IN2_ON();
    
    
    InitOC1Pin();
    SetOC1AsPWM();
    
    
    InitTimer2();
    StartTimer2();

    
    
//    // Initialize I2C and ADC modules
//    InitI2C();
    InitAdc1();
}


void Config_LED1_Pin(void)
{
    _TRISA0 = 0;
    _PCFG0 = 1;  // output i/o for LED1
}


void Config_LED2_Pin(void)
{
    _TRISA1 = 0;
    _PCFG1 = 1;  // output i/o for LED2
}


//ENABLE control
void ENABLE_ON(void)
{
    ENABLE_PIN = 1;
}

void ENABLE_OFF(void)
{
    ENABLE_PIN = 0;
}
void ENABLE_TOGGLE(void)
{
    ENABLE_PIN = ~ENABLE_PIN;
}

//IN1 control 
void IN1_ON(void)
{
    IN1_PIN = 1;
}

void IN1_OFF(void)
{
    IN1_PIN = 0;
}

void IN1_TOGGLE(void) 
{
    IN1_PIN = ~IN1_PIN;
}

//IN2 control 
void IN2_ON(void) 
{
    IN2_PIN = 1;
}

void IN2_OFF(void)
{
    IN2_PIN = 0;
}

void IN2_TOGGLE(void)
{
    IN2_PIN =~ IN2_PIN;
}

void LIMSW_HOLD(void)
{
    LIMSW_PIN = LIMSW_PIN;
}


void LED1_ON(void)
{
    LED1_PIN=1;
}


void LED1_OFF(void)
{
    LED1_PIN=0;
}


void LED1_TOGGLE(void)
{
    LED1_PIN=~LED1_PIN;
}


void LED2_ON(void)
{
    LED2_PIN=1;
}


void LED2_OFF(void)
{
    LED2_PIN=0;
}


void LED2_TOGGLE(void)
{
    LED2_PIN=~LED2_PIN;
}


void INIT_MAIN_TIMER(void)
{
    InitTimer1();
}


void START_MAIN_TIMER(void)
{
    StartTimer1();
}


void STOP_MAIN_TIMER(void)
{
    StopTimer1();
}


unsigned long GET_CURRENT_TIME(void)
{
    return (GetTimer1CounterValue());
}


void CLEAR_ALL_INTERRUPTS(void)
{
    IFS0=0;
    IFS1=0;
    IFS2=0;
    IFS3=0;
    IFS4=0;
}


