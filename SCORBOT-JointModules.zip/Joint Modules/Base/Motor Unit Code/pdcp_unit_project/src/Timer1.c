
/*
 * File:   Timer1.c
 * Author: yveslosier
 *
 * Created on February 18, 2014, 10:49 PM
 */

#include "Timer1.h"

#include "p33Fxxxx.h"

unsigned long volatile timer1Counter;


void InitTimer1(void)
{
    StopTimer1();

    TMR1 = 0x0000;   // Clear timer 1
    PR1 = 16000;   // Interrupt every 1ms
    IFS0bits.T1IF = 0;   // Clear interrupt flag

    IEC0bits.T1IE = 1;   // Set interrupt enable bit
}


void StartTimer1(void)
{
   T1CONbits.TON = 1;
}


void StopTimer1(void)
{
   T1CONbits.TON = 0;
}


unsigned long GetTimer1CounterValue(void)
{
    unsigned long volatile currentValue;

    if (_T1IE == 1)
    {
        _T1IE = 0;
        currentValue = timer1Counter;
        _T1IE = 1;
    }
    else
    {
        currentValue = timer1Counter;
    }

    return currentValue;
}


void enableSecOsc(void)
{
    __builtin_write_OSCCONL(0x02);   // Start secondary clock
}


void disableSecOsc(void)
{
    __builtin_write_OSCCONL(0x00);   // Stop secondary clock
}


void __attribute__((interrupt,auto_psv)) _T1Interrupt(void)
{
    _T1IF = 0;
    timer1Counter++;
}




