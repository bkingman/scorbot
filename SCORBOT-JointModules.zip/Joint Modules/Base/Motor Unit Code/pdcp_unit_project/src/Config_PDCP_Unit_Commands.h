/* 
 * File:   Config_PDCP_Unit_Commands.h
 * Author: yveslosier
 *
 * Created on February 18, 2014, 10:23 PM
 */

#ifndef CONFIG_PDCP_Unit_COMMANDS_H
#define	CONFIG_PDCP_Unit_COMMANDS_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "Config_Micro.h"


// Defining the OSI Layer 1 hardware platform
#define CAN

// Specifying the hardware functions necessary to implement the hardware layer for the PDCP protocol
#ifdef CAN

    #include "CAN1.h"
    #include "CANcommon.h"
    #include "CANmessage.h"

    void SEND_PDCP_MESSAGE_TO_HARDWARE_QUEUE(PDCPMESSAGE * PDCPMessage);
    unsigned char PDCP_MESSAGE_AVAILABLE_FROM_HARDWARE_QUEUE(void);
    unsigned char RETRIEVE_PDCP_MESSAGE_FROM_HARDWARE_QUEUE(PDCPMESSAGE * messageLocation);
    void UPDATE_PDCP_HARDWARE_STATE_MACHINES(void);

    void PDCP_COMMAND_HARDWARE_CONFIG(void);
    void ConfigHardwareMaskAndFilter(unsigned char nodeId, unsigned char boundFlag);

    unsigned char MAX_DATA_PAYLOAD_PER_HARDWARE_MESSAGE(void);
    unsigned char MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE(void);
    unsigned char MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE(void);
    unsigned char MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_HARDWARE_SIZE(void);

#else
   #error No Hardware Platform Define.
#endif



#ifndef NULL_POINTER
   #define NULL_POINTER 0
#endif
    

#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_PDCP_COMMANDS_H */

