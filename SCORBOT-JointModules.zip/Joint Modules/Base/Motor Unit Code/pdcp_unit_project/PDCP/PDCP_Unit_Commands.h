/* 
 * File:   PDCP_Commands.h
 * Author: yveslosier
 *
 * Created on February 18, 2014, 10:20 PM
 */

#ifndef PDCP_COMMANDS_H
#define	PDCP_COMMANDS_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "PDCP.h"


#define MAX_NUM_OF_PDCP_MESSAGES         64


//------------------------------------------------------------------------
//
// Prosthetic Device Communication Protocol Function Code Definitions
//
//------------------------------------------------------------------------

#define PDCP_COMMAND_UNKNOWN                        0x00  // N/A.. YL

#define PDCP_COMMAND_BIND_REQUEST                   0x01
#define PDCP_COMMAND_GET_UNIT_INFO                  0x02  // Deprecated.. YL
#define PDCP_COMMAND_GET_UNIT_PARAMETER             0x03
#define PDCP_COMMAND_SET_UNIT_PARAMETER             0x04
#define PDCP_COMMAND_INDIRECT_GET_UNIT_PARAMETER    0x05  // Deprecated.. YL
#define PDCP_COMMAND_INDIRECT_SET_UNIT_PARAMETER    0x06  // Deprecated.. YL
#define PDCP_COMMAND_SET_NODE_ID                    0x07  // Deprecated.. YL
#define PDCP_COMMAND_SUSPEND_UNIT                   0x08
#define PDCP_COMMAND_RELEASE_UNIT                   0x09
#define PDCP_COMMAND_NODE_BEACON                    0x0A
#define PDCP_COMMAND_RESET_UNIT                     0x0B
#define PDCP_COMMAND_CONFIG_GET_BULK_DATA_TRANSFER  0x0C
#define PDCP_COMMAND_CONFIG_SET_BULK_DATA_TRANSFER  0x0D
#define PDCP_COMMAND_BULK_DATA_TRANSFER             0x0E
#define PDCP_COMMAND_UPDATE_DATA_CHANNEL_LINK       0x0F  // Deprecated.. YL



#define PDCP_RESPONSE_UNKNOWN                       0x80  // N/A.. YL

#define PDCP_RESPONSE_BIND_REQUEST                  0x81
#define PDCP_RESPONSE_GET_UNIT_INFO                 0x82  // Deprecated.. YL
#define PDCP_RESPONSE_GET_UNIT_PARAMETER            0x83
#define PDCP_RESPONSE_SET_UNIT_PARAMETER            0x84
#define PDCP_RESPONSE_INDIRECT_GET_UNIT_PARAMETER   0x85  // Deprecated.. YL
#define PDCP_RESPONSE_INDIRECT_SET_UNIT_PARAMETER   0x86  // Deprecated.. YL
#define PDCP_RESPONSE_SET_NODE_ID                   0x87  // Deprecated.. YL
#define PDCP_RESPONSE_SUSPEND_UNIT                  0x88
#define PDCP_RESPONSE_RELEASE_UNIT                  0x89
#define PDCP_RESPONSE_NODE_BEACON                   0x8A  // N/A.. YL
#define PDCP_RESPONSE_RESET_UNIT                    0x8B
#define PDCP_RESPONSE_CONFIG_GET_BULK_DATA_TRANSFER 0x8C
#define PDCP_RESPONSE_CONFIG_SET_BULK_DATA_TRANSFER 0x8D
#define PDCP_RESPONSE_BULK_DATA_TRANSFER            0x8E
#define PDCP_RESPONSE_UPDATE_DATA_CHANNEL_LINK      0x8F  // Deprecated.. YL



//------------------------------------------------------------------------




//------------------------------------------------------------------------
//
// Prosthetic Device Communication Protocol Various Definitions
//
//------------------------------------------------------------------------

#define PDCP_RESPONSE_CODE_FAILURE       0x00
#define PDCP_RESPONSE_CODE_SUCCESSFUL    0x01
#define PDCP_RESPONSE_CODE_USE_BULK_DATA 0x02

#define PDCP_PRIORITY_HIGH   0
#define PDCP_PRIORITY_NORMAL 1
#define PDCP_PRIORITY_LOW    2
#define PDCP_PRIORITY_BIND   3

#define PDCP_STANDARD_MESSAGE_MODE 0
#define PDCP_MASTER_MESSAGE_MODE   1

#define UNIT_CHANNEL_INDEX 0


//------------------------------------------------------------------------


typedef struct unknownMessage UNKNOWN_PDCP_TYPE_MESSAGE;

struct unknownMessage
{
    unsigned char functionCode;
};




typedef struct bindUnitRequest BIND_UNIT_REQUEST_MESSAGE;

struct bindUnitRequest
{

   unsigned char functionCode;

   union
   {
      unsigned int VID __attribute__((packed));

      struct
      {
         unsigned char VID_LSB;
         unsigned char VID_MSB;
      };

      struct
      {
         unsigned char LSB;
         unsigned char MSB;
      } VID_Bytes;
   };

   union
   {
      unsigned int PID __attribute__((packed));

      struct
      {
         unsigned char PID_LSB;
         unsigned char PID_MSB;
      };

      struct
      {
         unsigned char LSB;
         unsigned char MSB;
      } PID_Bytes;
   };

   union
   {
      unsigned int SN __attribute__((packed));

      struct
      {
         unsigned char SN_LSB;
         unsigned char SN_MSB;
      };

      struct
      {
         unsigned char LSB;
         unsigned char MSB;
      } SN_Bytes;
   };
};


typedef struct bindUnitRequestResponse BIND_UNIT_REQUEST_RESPONSE_MESSAGE;

struct bindUnitRequestResponse
{
    unsigned char functionCode;
    unsigned char responseNodeId;
    unsigned int VID __attribute__((packed));
    unsigned int PID __attribute__((packed));
    unsigned int SN __attribute__((packed));
};


typedef struct getUnitParameterCommand GET_UNIT_PARAMETER_COMMAND_MESSAGE;

struct getUnitParameterCommand
{
   unsigned char functionCode;
   unsigned char parameterId;
   unsigned char channelIndex;
};



typedef struct getUnitParameterResponse GET_UNIT_PARAMETER_RESPONSE_MESSAGE;

struct getUnitParameterResponse
{
   unsigned char functionCode;
   unsigned char responseCode;
   unsigned char parameterId;
   unsigned char channelIndex;
   unsigned char parameterData[4];
};


typedef struct setUnitParameterCommand SET_UNIT_PARAMETER_COMMAND_MESSAGE;

struct setUnitParameterCommand
{
   unsigned char functionCode;
   unsigned char parameterId;
   unsigned char channelIndex;
   unsigned char parameterData[4];
};


typedef struct setUnitParameterResponse SET_UNIT_PARAMETER_RESPONSE_MESSAGE;

struct setUnitParameterResponse
{
   unsigned char functionCode;
   unsigned char responseCode;
   unsigned char parameterId;
   unsigned char channelIndex;
   unsigned char parameterData[4];
   unsigned char parameterDataSize;
};


typedef struct genericUnitResponse RESET_UNIT_RESPONSE_MESSAGE;
typedef struct genericUnitResponse BULK_DATA_TRANSFER_RESPONSE_MESSAGE;

struct genericUnitResponse
{
   unsigned char functionCode;
   unsigned char responseCode;
};


typedef struct configGetBulkDataResponse CONFIG_GET_BULK_DATA_RESPONSE_MESSAGE;

struct configGetBulkDataResponse
{
   unsigned char functionCode;
   unsigned char responseCode;
   unsigned char parameterId;
   unsigned char channelIndex;
   unsigned int  bulkDataSize;
};


typedef struct configSetBulkDataCommand CONFIG_SET_BULK_DATA_COMMAND_MESSAGE;

struct configSetBulkDataCommand
{
   unsigned char functionCode;
   unsigned char parameterId;
   unsigned char channelIndex;

   union
   {
      unsigned int bulkDataSize __attribute__((packed));

      struct
      {
         unsigned char bulkDataSize_LSB;
         unsigned char bulkDataSize_MSB;
      };
   };
};


typedef struct configSetBulkDataResponse CONFIG_SET_BULK_DATA_RESPONSE_MESSAGE;

struct configSetBulkDataResponse
{
   unsigned char functionCode;
   unsigned char responseCode;
   unsigned char parameterId;
   unsigned char channelIndex;
   unsigned int  bulkDataSize;
};


void InitPDCPCommands(void);
void UpdatePDCPCommandsStateMachine(void);

unsigned char PdcpMessageAvailableInQueue(void);
PDCPMESSAGE * GetPdcpMessageFromQueue(void);

void SEND_PDCP_MESSAGE(PDCPMESSAGE * currentPDCPMessage);

// ------------------------------------------------------------
// PDCP Message creation related function prototypes
// ------------------------------------------------------------

void CREATE_UNKNOWN_FUNCTION_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId);
void CREATE_BIND_REQUEST_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned int VID, unsigned int PID, unsigned int SN);
void CREATE_BIND_REQUEST_RESPONSE_MESSAGE(PDCPMESSAGE * newPDCPMessage, PDCPMESSAGE * currentPDCPMessage, unsigned char assignedNodeId);
void CREATE_GET_UNIT_PARAMETER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex);
void CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length);
void CREATE_SET_UNIT_PARAMETER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length);
void CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length);
void CREATE_BEACON_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId);
void CREATE_RESET_UNIT_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId);
void CREATE_CONFIG_GET_BULK_DATA_TRANSFER(PDCPMESSAGE * PDCPMessage, PDCPMESSAGE * currentPDCPMessage);
void CREATE_CONFIG_SET_BULK_DATA_TRANSFER(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned int length);
void CREATE_CONFIG_SET_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned int length);
void CREATE_BULK_DATA_TRANSFER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned char packetId, unsigned char *data, unsigned int length);
void CREATE_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char responseCode);
void CREATE_STANDARD_PASSTHROUGH_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char *data, unsigned int length, unsigned char functionFlag);

// ------------------------------------------------------------
// PDCP Message handling related function prototypes
// ------------------------------------------------------------
void InitPdcpMessageList(void);

PDCPMESSAGE * FindEmptyPdcpMessageLocation(void);
PDCPMESSAGE * FindPdcpMessageByNodeId(unsigned int nodeId);

void AppendPdcpMessageToEmptyPdcpMessageList(PDCPMESSAGE *lnode);
void InsertPdcpMessageToEmptyPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *after);
void RemovePdcpMessageFromEmptyPdcpMessageList(PDCPMESSAGE *lnode);

// These functions are used for the RX Messages
void AppendPdcpMessageToPdcpMessageList(PDCPMESSAGE *lnode);
void InsertPdcpMessageBeforeToPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *before);
void InsertPdcpMessageAfterToPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *after);
void RemovePdcpMessageFromPdcpMessageList(PDCPMESSAGE *lnode);
// ------------------------------------------------------------


unsigned char MAX_DATA_PAYLOAD_PER_MESSAGE(void);
unsigned char MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_SIZE(void);
unsigned char MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_SIZE(void);
unsigned char MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_SIZE(void);

void CONFIG_MASK_AND_FILTER(unsigned char nodeId,unsigned char unitBoundFlag);

#ifdef	__cplusplus
}
#endif

#endif	/* PDCP_COMMANDS_H */

