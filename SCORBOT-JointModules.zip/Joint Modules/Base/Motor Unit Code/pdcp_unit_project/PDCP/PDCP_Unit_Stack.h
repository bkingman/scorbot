/* 
 * File:   PDCP_Unit_Stack.h
 * Author: Yves
 *
 * Created on July 1, 2014, 12:58 AM
 */

#ifndef PDCP_Unit_STACK_H
#define	PDCP_Unit_STACK_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "PDCP.h"


#define BINDREQUEST_TIMEOUT_INTERVAL 100
#define MAX_NUM_OF_TIMEOUTS 50

#define BEACON_INTERVAL 500

    
//------------------------------------------------------------------------
//
// Prosthetic Device Communication Protocol Paraneter Addresses
//
//------------------------------------------------------------------------

#define PARAMETER_ADDRESS_UNIT_VID_PID                              1
#define PARAMETER_ADDRESS_UNIT_SERIAL_NUMBER                        2
#define PARAMETER_ADDRESS_UNIT_EAN13L                               3
#define PARAMETER_ADDRESS_UNIT_EAN13H                               4
#define PARAMETER_ADDRESS_UNIT_FW_HW_VER                            5
#define PARAMETER_ADDRESS_UNIT_TYPE_PROFILE                         6
#define PARAMETER_ADDRESS_UNIT_DESCRIPTOR                           7
#define PARAMETER_ADDRESS_UNIT_NODE_ID                              8
#define PARAMETER_ADDRESS_UNIT_NUM_OF_DATA_CHANNELS                 9
#define PARAMETER_ADDRESS_UNIT_BEACON_INTERVAL                     10
#define PARAMETER_ADDRESS_UNIT_TIME_TO_ACKNOWLEDGE                 11
#define PARAMETER_ADDRESS_UNIT_TIME_BEFORE_SLEEP                   12
#define PARAMETER_ADDRESS_UNIT_BIND_REQUEST_TIMEOUT                13
#define PARAMETER_ADDRESS_UNIT_API_SOCKET                          14

#define PARAMETER_ADDRESS_DATA_CHANNEL_TYPE_PROFILE                   1
#define PARAMETER_ADDRESS_DATA_CHANNEL_DESCRIPTOR                     2
#define PARAMETER_ADDRESS_DATA_CHANNEL_TRANSFER_TYPE                  3
#define PARAMETER_ADDRESS_DATA_CHANNEL_TRANSFER_ENABLE_FLAG           4

#define UNKNOWN_DATA_CHANNEL_TRANSFER_TYPE                            0
#define INPUT_DATA_CHANNEL_TRANSFER_TYPE                              1
#define OUTPUT_DATA_CHANNEL_TRANSFER_TYPE                             2

// If (Data Channel's Transfer Type == 1) ...
#define PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_VID_PID           5
#define PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_SN_CHANNEL_INDEX  6
#define PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_NODE_IDS          7

// If (Data Channel's Transfer Type == 2) ...
#define PARAMETER_ADDRESS_OUTPUT_DATA_CHANNEL_NODE_ID                 5

//------------------------------------------------------------------------







//---------------------------------------------------------------------------
// PDCP related structure definitions for Unit, Data Channel, and Parameters
//---------------------------------------------------------------------------

// Structure defining a PDCP Unit
typedef struct unit UNIT;

// Structure defining a PDCP Data Channel
typedef struct data_channel DATA_CHANNEL;

// Structure used to store generic unit info
typedef struct unitInfo UNIT_INFO;

// Structure used to store all binding related variables
typedef struct PDCPBindVars PDCP_BIND_VARS;

// Structure used to store bulk data related variables
typedef struct PDCPBulkDataVars PDCP_BULK_DATA_VARS;

// Structure used to store generic data channel parameters (regardless of transfer type)
typedef struct generic_data_channel_parameters GENERIC_DATA_PARAMETERS;

// Structure used to store generic unit info
typedef struct input_data_channels_parameters  INPUT_DATA_PARAMETERS;

// Structure used to store generic unit info
typedef struct output_data_channels_parameters OUTPUT_DATA_PARAMETERS;

// Structure used to stored descriptor info
typedef struct descriptor DESCRIPTOR;

//---------------------------------------------------------------------------




//---------------------------------------------------------------------------
// PDCP related structure declarations for Unit, Data Channel, and Parameters
//---------------------------------------------------------------------------

struct descriptor
{
   unsigned char *ptr;
   unsigned char size;
};

struct unitInfo
{
    unsigned int BID;                // Unit's PDCP Board Id
    unsigned int VID;                // Unit's VID
    unsigned int PID;                // Unit's PID
    unsigned int SN;                 // Unit's SN
    unsigned long long EAN13;        // PDCP Device EAN13
    unsigned int firmwareVersion;    // Unit's FW version
    unsigned int hardwareVersion;    // Unit's HW version
    unsigned int type;               // Unit Type
    unsigned int profile;            // Unit Profile
    DESCRIPTOR descriptor;           // Unit Descriptor
    unsigned char nodeId;            // Unit's control nodeId
    unsigned char numOfDataChannels; // # of data channel on this unit
    unsigned int beaconInterval;     // Unit's beacon interval
};


struct PDCPBindVars
{
    unsigned int  initialDelayValue;  // Initial delay value (in ms) prior to attempting to bind
    unsigned char unitBound;          // Flag indicating if the unit is bound or not
    unsigned char numOfTimeouts ;     // Counter for number of timeouts that have occured during the binding process
    unsigned long responseTimeout;    // Timer value indicating when the next timeout will occur
};


struct PDCPBulkDataVars
{
    unsigned char *Ptr;     // Location of bulk data being received during a Bulk_Data communication exchange with bus arbitrator
    unsigned int   Size;    // The total size of the bulk data transfer
    unsigned int   Ctr;     // Current index location of bulk data being transfered
    unsigned char  Flag;    // Message flag indicating that there is bulk data being received/transmitted
    unsigned char  CI;      // Channel Index associated with desired variable location
    unsigned char  ParamId; // Parameter Id associated with desired variable location
};


struct generic_data_channel_parameters
{
   unsigned char channelIndex;  // UNIT Index for Data Channel
   unsigned int type;           // Data Channel Type
   unsigned int profile;        // Data Channel Profile
   DESCRIPTOR descriptor;       // String Descriptor for Data Channel
   unsigned char transferType;        // Data Channel Type (0 == unknown, 1 == input, 2 == output, 3 == aux)
   unsigned char transferEnableFlag;  // Indicates if data can be received or transmitted by data channel
};


struct input_data_channels_parameters
{
    unsigned int  sourceVID;  // VID of unit streaming data to the input data cannel
    unsigned int  sourcePID;  // PID of unit streaming data to the input data cannel
    unsigned int  sourceSN;   // SN  of unit streaming data to the input data cannel
    unsigned char sourceCI;   // Channel Index of unit streaming data to the input data cannel
    unsigned char sourceUnitNodeId;  // Control Node Id of unit streaming data to the input data cannel
    unsigned char sourceChannelNodeId;  // Node Id associated with output data channel streaming data to the input data cannel

    void* parameters;  // Pointer to data channel specific parameters
};


struct output_data_channels_parameters
{
   unsigned char nodeId;  // Node Id associated with this output data channel

   void* parameters;  // Pointer to data channel specific parameters
};


struct unit
{
   UNIT_INFO devInfo;  // Generic unit info as defined by the PDCP
   void *parameters;   // Pointer to unit specific parameters

   DATA_CHANNEL *headDataChannelList;  // Head of data channel link list for given unit
   DATA_CHANNEL *tailDataChannelList;  // Tail of data channel link list for given unit

   PDCPMESSAGE *headTxMessage;   // Head of Tx PDCP message link list for given unit
   PDCPMESSAGE *tailTxMessage;   // Tail of Tx PDCP message link list for given unit
   unsigned char PDCPBufferSize; // Max Number of PDCP Message stored in unit buffer
   unsigned char busId;          // Identifies the hardware layer used by unit (ex: CAN)

   PDCP_BIND_VARS bindVars;  // Structure used to handle binding sequence
   PDCP_BULK_DATA_VARS bulkDataVars;  // Structure used to handle bulk data transfers
};


struct data_channel
{
   GENERIC_DATA_PARAMETERS channel_info;  // Generic data channel info as defined by the PDCP

   UNIT *parent;                 // Unit associated with the Data Channel
   DATA_CHANNEL *prev;           // Pointer to previous data channel in link list for the given unit
   DATA_CHANNEL *next;           // Pointer to next data channel in the link list for the given unit

   PDCPMESSAGE *headMessage;     // Head of PDCP message link list for given data channel
   PDCPMESSAGE *tailMessage;     // Tail of PDCP message link list for given data channel

   unsigned char numOfMessages;  // Current number of PDCP messages in data channel buffer
   unsigned char PDCPBufferSize; // Max Number of PDCP Message stored in data channel buffer
   unsigned char dataChannelStructureId; // Defines an Id for the type of data structure used by the data channel

   // Pointer to either input or output data channel specific parameters.
   // Input or output depends on the transfer type variable value located in channel_info
   void* parameters;
};
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
// PDCP related functions
//---------------------------------------------------------------------------

void BindUnit(UNIT* unit);

void UpdatePDCPStackStateMachine(UNIT* unit);

void ProcessPDCPMessage(UNIT * unit, PDCPMESSAGE * currentPDCPMessage);

void AppendDataChannelToDataChannelList(DATA_CHANNEL *lnode);

UNIT* CreateUnit(void);
DATA_CHANNEL* AddDataChannel(UNIT* parentUnit, unsigned char channelType, unsigned int bufferSize);
DATA_CHANNEL * FindDataChannelByChannelIndex(UNIT * currentUnit, unsigned char channelIndex);

void StoreBulkDataFromUnitIntoMemory(UNIT * currentUnit, PDCPMESSAGE *PDCPMessage);

void UpdateBeacon(UNIT * unit, unsigned long currentTime);
void UpdateTimeout(UNIT* unit);

unsigned char IsMessageForThisUnit(UNIT* unit, PDCPMESSAGE* currentPDCPMessage);

void AppendMessageToPDCPMessageListOfDataChannel(DATA_CHANNEL   *lnode, PDCPMESSAGE *PDCPMessage);
void RemoveMessageFromPDCPMessageListOfDataChannel(DATA_CHANNEL *lnode, PDCPMESSAGE *PDCPMessage);

unsigned char IsInputDataChannelMessageAvailable(DATA_CHANNEL* dataChannel);
unsigned char SizeOfInputDataChannelMessage(DATA_CHANNEL* dataChannel);
void GetDataFromInputDataChannelMessage(DATA_CHANNEL* dataChannel, unsigned char* destination);

unsigned char SendDataOnOutputDataChannel(DATA_CHANNEL* dataChannel, unsigned char* origin, unsigned int length);

void StoreBulkDataIntoMemory(UNIT *unit, PDCPMESSAGE *PDCPMessage);
//---------------------------------------------------------------------------


#ifdef	__cplusplus
}
#endif

#endif	/* PDCP_Unit_STACK_H */

