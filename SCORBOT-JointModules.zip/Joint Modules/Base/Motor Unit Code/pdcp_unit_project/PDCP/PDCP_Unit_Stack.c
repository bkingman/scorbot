
#include <string.h>
#include <stdlib.h>

#include "PDCP_Unit_Commands.h"
#include "PDCP_Unit_Stack.h"

#include "Config_Micro.h"
#include "Config_Unit.h"


void UpdatePDCPStackStateMachine(UNIT* unit)
{
    PDCPMESSAGE   * currentPDCPMessage;

    if (PdcpMessageAvailableInQueue())
    {
        currentPDCPMessage = GetPdcpMessageFromQueue();
        ProcessPDCPMessage(unit, currentPDCPMessage);
        RemovePdcpMessageFromPdcpMessageList(currentPDCPMessage);
        AppendPdcpMessageToEmptyPdcpMessageList(currentPDCPMessage);
    }

    if (!unit->bindVars.unitBound)
    {
        UpdateTimeout(unit);
    }
    else
    {
        UpdateBeacon(unit, GET_CURRENT_TIME());
        LED1_ON();
    }
}


void AppendDataChannelToDataChannelList(DATA_CHANNEL *lnode)
{
   if(lnode->parent->headDataChannelList == NULL_POINTER)
   {
      lnode->parent->headDataChannelList = lnode;
      lnode->prev = NULL_POINTER;
   }
   else
   {
      lnode->parent->tailDataChannelList->next = lnode;
      lnode->prev = lnode->parent->tailDataChannelList;
   }

   lnode->parent->tailDataChannelList = lnode;
   lnode->next = NULL_POINTER;

   lnode->parent->devInfo.numOfDataChannels++;
}


DATA_CHANNEL * FindDataChannelByChannelIndex(UNIT * currentUnit, unsigned char channelIndex)
{
   unsigned char i;
   DATA_CHANNEL * currentChannel;

   if (currentUnit != NULL_POINTER)
   {
       for (i=1;i<=currentUnit->devInfo.numOfDataChannels;i++)
       {
          if (i==1)
          {
             currentChannel = currentUnit->headDataChannelList;
          }

          if (currentChannel->channel_info.channelIndex==channelIndex)
          {
             return currentChannel;
          }

          currentChannel = currentChannel->next;
       }
   }

   return NULL_POINTER;
}




UNIT* CreateUnit(void)
{
   UNIT * newUnit;

   newUnit = (UNIT*) calloc(1,sizeof(UNIT));

   return newUnit;
}


DATA_CHANNEL* AddDataChannel(UNIT* parentUnit, unsigned char channelType, unsigned int bufferSize)
{
   DATA_CHANNEL *newDataChannel;

   newDataChannel = (DATA_CHANNEL*) calloc(1,sizeof(DATA_CHANNEL));
   newDataChannel->parent = parentUnit;

   AppendDataChannelToDataChannelList(newDataChannel);

   newDataChannel->channel_info.channelIndex = parentUnit->devInfo.numOfDataChannels;
   newDataChannel->channel_info.transferType = channelType;

   newDataChannel->PDCPBufferSize = bufferSize;

   if (channelType == INPUT_DATA_CHANNEL_TRANSFER_TYPE)
   {
       INPUT_DATA_PARAMETERS * newInputDataParameters;
       newInputDataParameters = (INPUT_DATA_PARAMETERS*) calloc(1,sizeof(INPUT_DATA_PARAMETERS));
       newDataChannel->parameters = newInputDataParameters;
   }
   else if (channelType == OUTPUT_DATA_CHANNEL_TRANSFER_TYPE)
   {
       OUTPUT_DATA_PARAMETERS * newOutputDataParameters;
       newOutputDataParameters = (OUTPUT_DATA_PARAMETERS*) calloc(1,sizeof(OUTPUT_DATA_PARAMETERS));
       newDataChannel->parameters = newOutputDataParameters;
   }

   return newDataChannel;
}


void StoreBulkDataFromUnitIntoMemory(UNIT * currentUnit, PDCPMESSAGE *PDCPMessage)
{
    memcpy((currentUnit->bulkDataVars.Ptr+currentUnit->bulkDataVars.Ctr),(PDCPMessage->data+2),(unsigned char)(PDCPMessage->length-2));

    currentUnit->bulkDataVars.Ctr = currentUnit->bulkDataVars.Ctr + (PDCPMessage->length-2);
}


void UpdateBeacon(UNIT * unit, unsigned long currentTime)
{
    static unsigned long nextBeaconTime;
    PDCPMESSAGE newPDCPMessage;

    if (currentTime>nextBeaconTime)
    {
        if (nextBeaconTime > 0)
        {
            CREATE_BEACON_MESSAGE(&newPDCPMessage, unit->busId, unit->devInfo.nodeId);
            SEND_PDCP_MESSAGE(&newPDCPMessage);
            free(newPDCPMessage.data);
        }

        nextBeaconTime = GET_CURRENT_TIME() + unit->devInfo.beaconInterval;
    }
}


void UpdateTimeout(UNIT* unit)
{
    PDCPMESSAGE newPDCPMessage;

    if (GET_CURRENT_TIME() > unit->bindVars.responseTimeout)
    {
        unit->bindVars.numOfTimeouts++;

        if (unit->bindVars.numOfTimeouts < MAX_NUM_OF_TIMEOUTS)
        {
            CREATE_BIND_REQUEST_MESSAGE(&newPDCPMessage, unit->busId, unit->devInfo.nodeId, unit->devInfo.VID, unit->devInfo.PID, unit->devInfo.SN);
            SEND_PDCP_MESSAGE(&newPDCPMessage);
            free(newPDCPMessage.data);

            unit->bindVars.responseTimeout = GET_CURRENT_TIME() + BINDREQUEST_TIMEOUT_INTERVAL;  // reset next timeout value...
        }
        else  // If unit exceeded max number of binding attempts...
        {
            while (1)
            {
                //Sleep();  // PowerDown UNIT

            }
        }
    }
}


void ProcessPDCPMessage(UNIT * unit, PDCPMESSAGE * currentPDCPMessage)
{
    DATA_CHANNEL       * currentDataChannel;
    PDCPMESSAGE        * currentTxMessage;
    PDCPMESSAGE        * headOfDataChannelMessages;


    INPUT_DATA_PARAMETERS  * inputParameters;
    OUTPUT_DATA_PARAMETERS * outputParameters;

    UNKNOWN_PDCP_TYPE_MESSAGE * UNKN;
    BIND_UNIT_REQUEST_RESPONSE_MESSAGE * BDRR;
    GET_UNIT_PARAMETER_COMMAND_MESSAGE * GDPC;
    SET_UNIT_PARAMETER_COMMAND_MESSAGE * SDPC;
    CONFIG_SET_BULK_DATA_COMMAND_MESSAGE * CSBDC;

    unsigned char parameterData[4];
    unsigned int  parameterDataLength;

    unsigned int VID, PID, SN; //TESTING ONLY!!!!

    unsigned char i;

    unsigned long currentTimerValue;

    if (!IsMessageForThisUnit(unit,currentPDCPMessage)) // If unit is intended for another unit
    {
        return;
    }

    if (currentPDCPMessage->nodeId == unit->devInfo.nodeId)  // if message is sent to the unit's control nodeId
    {
        UNKN = (UNKNOWN_PDCP_TYPE_MESSAGE *)currentPDCPMessage->data;

        if (unit->bindVars.unitBound == 0)  // If unit is not yet bound, only handle bind request responses...
        {
            switch(UNKN->functionCode)
            {
                case PDCP_RESPONSE_BIND_REQUEST:

                    BDRR = (BIND_UNIT_REQUEST_RESPONSE_MESSAGE *)UNKN;

                    VID = (((unsigned int)currentPDCPMessage->data[3])<<8)+currentPDCPMessage->data[2];
                    PID = (((unsigned int)currentPDCPMessage->data[5])<<8)+currentPDCPMessage->data[4];
                    SN  = (((unsigned int)currentPDCPMessage->data[7])<<8)+currentPDCPMessage->data[6];

                    //if ((BDRR->VID == unit->devInfo.VID) && (BDRR->PID == unit->devInfo.PID) && (BDRR->SN == unit->devInfo.SN)) // if the message is for this unit AND it is a bind request response...
                    if ((VID == unit->devInfo.VID) && (PID == unit->devInfo.PID) && (SN == unit->devInfo.SN)) // if the message is for this unit AND it is a bind request response...
                    {
                        //if (BDRR->responseNodeId == unit->devInfo.nodeId)  // was the nodeId accepted?
                        if (currentPDCPMessage->data[1] == unit->devInfo.nodeId)  // was the nodeId accepted?
                        {
                            unit->bindVars.unitBound = 1;
                        }
                        else
                        {
                            //unit->devInfo.nodeId = BDRR->responseNodeId;
                            unit->devInfo.nodeId = currentPDCPMessage->data[1];

                            currentTxMessage = FindEmptyPdcpMessageLocation();
                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                            CREATE_BIND_REQUEST_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, unit->devInfo.VID, unit->devInfo.PID, unit->devInfo.SN);
                            SEND_PDCP_MESSAGE(currentTxMessage);
                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                            unit->bindVars.responseTimeout = GET_CURRENT_TIME() + BINDREQUEST_TIMEOUT_INTERVAL;  // reset next timeout value...
                        }
                    }
                    else
                    {
                        // Do nothing... bind request response not intended for this unit.
                    }
                
                    break;

                default:

                    // Do nothing... message was not a bind request response from Bus Arbitrator.

                    break;
            }
        }
        else  // If unit is bound, handle any messages sent to its control node
        {
            switch(UNKN->functionCode)
            {

                case PDCP_COMMAND_NODE_BEACON:
                    // Beacon sent from Bus Arbitrator... can be used to ensure unit is still on bus...
                    break;
                case PDCP_COMMAND_GET_UNIT_PARAMETER:

                    GDPC = (GET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;

                    if (GDPC->channelIndex == UNIT_CHANNEL_INDEX)
                    {
                        switch (GDPC->parameterId)
                        {
                            case PARAMETER_ADDRESS_UNIT_VID_PID:

                                parameterData[0]=(unsigned char)(unit->devInfo.VID);
                                parameterData[1]=(unsigned char)(unit->devInfo.VID >> 8);
                                parameterData[2]=(unsigned char)(unit->devInfo.PID);
                                parameterData[3]=(unsigned char)(unit->devInfo.PID >> 8);

                                parameterDataLength = 4;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_SERIAL_NUMBER:

                                parameterData[0]=(unsigned char)(unit->devInfo.SN);
                                parameterData[1]=(unsigned char)(unit->devInfo.SN >> 8);

                                parameterDataLength = 2;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_EAN13L:

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_EAN13H:

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_FW_HW_VER:

                                parameterData[0]=(unsigned char)(unit->devInfo.firmwareVersion);
                                parameterData[1]=(unsigned char)(unit->devInfo.firmwareVersion >> 8);
                                parameterData[2]=(unsigned char)(unit->devInfo.hardwareVersion);
                                parameterData[3]=(unsigned char)(unit->devInfo.hardwareVersion >> 8);

                                parameterDataLength = 4;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_TYPE_PROFILE:

                                parameterData[0]=(unsigned char)(unit->devInfo.type);
                                parameterData[1]=(unsigned char)(unit->devInfo.type >> 8);
                                parameterData[2]=(unsigned char)(unit->devInfo.profile);
                                parameterData[3]=(unsigned char)(unit->devInfo.profile >> 8);

                                parameterDataLength = 4;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_DESCRIPTOR:
                                //TODO: Implement Bulk data Transfer Response code reply once bulk data transfer functions is implemented in the code

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                //CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_USE_BULK_DATA, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_NODE_ID:

                                parameterData[0]=(unsigned char)(unit->devInfo.nodeId);

                                parameterDataLength = 1;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_UNIT_NUM_OF_DATA_CHANNELS:

                                parameterData[0]=(unsigned char)(unit->devInfo.numOfDataChannels);

                                parameterDataLength = 1;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            default:

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                        } // end of switch (GDPC->parameterId)
                    }
                    else if (GDPC->channelIndex <= unit->devInfo.numOfDataChannels)
                    {
                        currentDataChannel = FindDataChannelByChannelIndex(unit, GDPC->channelIndex);

                        switch (GDPC->parameterId)
                        {
                            case PARAMETER_ADDRESS_DATA_CHANNEL_TYPE_PROFILE:

                                parameterData[0]=(unsigned char)(currentDataChannel->channel_info.type);
                                parameterData[1]=(unsigned char)(currentDataChannel->channel_info.type >> 8);
                                parameterData[2]=(unsigned char)(currentDataChannel->channel_info.profile);
                                parameterData[3]=(unsigned char)(currentDataChannel->channel_info.profile >> 8);

                                parameterDataLength = 4;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_DATA_CHANNEL_DESCRIPTOR:
                                //TODO: Implement Bulk data Transfer Response code reply once bulk data transfer functions is implemented in the code

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                //CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentPDCPMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_USE_BULK_DATA, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_DATA_CHANNEL_TRANSFER_TYPE:

                                parameterData[0]=currentDataChannel->channel_info.transferType;

                                parameterDataLength = 1;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            case PARAMETER_ADDRESS_DATA_CHANNEL_TRANSFER_ENABLE_FLAG:

                                parameterData[0]=currentDataChannel->channel_info.transferEnableFlag;

                                parameterDataLength = 1;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            default:

                                switch (currentDataChannel->channel_info.transferType)
                                {
                                    case INPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        inputParameters = (INPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (GDPC->parameterId)
                                        {
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_VID_PID:

                                                parameterData[0]=(unsigned char)(inputParameters->sourceVID);
                                                parameterData[1]=(unsigned char)(inputParameters->sourceVID >> 8);
                                                parameterData[2]=(unsigned char)(inputParameters->sourcePID);
                                                parameterData[3]=(unsigned char)(inputParameters->sourcePID >> 8);

                                                parameterDataLength = 4;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_SN_CHANNEL_INDEX:

                                                parameterData[0]=(unsigned char)(inputParameters->sourceSN);
                                                parameterData[1]=(unsigned char)(inputParameters->sourceSN >> 8);
                                                parameterData[2]=(unsigned char)(inputParameters->sourceCI);

                                                parameterDataLength = 3;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_NODE_IDS:

                                                parameterData[0]=inputParameters->sourceUnitNodeId;
                                                parameterData[1]=inputParameters->sourceChannelNodeId;

                                                parameterDataLength = 2;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,inputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_GET_UNIT_PARAMETER);

                                                break;
                                        }
                                        break;
                                    case OUTPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        outputParameters = (OUTPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (GDPC->parameterId)
                                        {
                                            case PARAMETER_ADDRESS_OUTPUT_DATA_CHANNEL_NODE_ID:

                                                parameterData[0]=outputParameters->nodeId;

                                                parameterDataLength = 1;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,outputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_GET_UNIT_PARAMETER);

                                                break;
                                        }
                                        break;
                                    default :

                                        parameterDataLength = 0;

                                        currentTxMessage = FindEmptyPdcpMessageLocation();
                                        RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                        CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                                        SEND_PDCP_MESSAGE(currentTxMessage);
                                        AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                        break;
                                }

                                break;
                        }
                    }
                    else
                    {
                        parameterDataLength = 0;

                        currentTxMessage = FindEmptyPdcpMessageLocation();
                        RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                        CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                        SEND_PDCP_MESSAGE(currentTxMessage);
                        AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
                    }// end of switch (GDPC->channelIndex)

                    break;
                case PDCP_COMMAND_SET_UNIT_PARAMETER:

                    SDPC = (SET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;

                    if (SDPC->channelIndex == UNIT_CHANNEL_INDEX)
                    {
                        switch (SDPC->parameterId)
                        {
                            default:

                                parameterDataLength = 0;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                        } // end of switch (GDPC->parameterId)
                    }
                    else if (SDPC->channelIndex <= unit->devInfo.numOfDataChannels)
                    {
                        currentDataChannel = FindDataChannelByChannelIndex(unit, SDPC->channelIndex);

                        switch (SDPC->parameterId)
                        {
                            case PARAMETER_ADDRESS_DATA_CHANNEL_TRANSFER_ENABLE_FLAG:

                                currentDataChannel->channel_info.transferEnableFlag = SDPC->parameterData[0];

                                parameterData[0] = SDPC->parameterData[0];
                                parameterDataLength = 1;

                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                            default:

                                switch (currentDataChannel->channel_info.transferType)
                                {
                                    case INPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        inputParameters = (INPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (SDPC->parameterId)
                                        {
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_VID_PID:

                                                inputParameters->sourceVID = (((unsigned int)SDPC->parameterData[1])<<8) + SDPC->parameterData[0];
                                                inputParameters->sourcePID = (((unsigned int)SDPC->parameterData[3])<<8) + SDPC->parameterData[2];

                                                parameterData[0] = SDPC->parameterData[0];
                                                parameterData[1] = SDPC->parameterData[1];
                                                parameterData[2] = SDPC->parameterData[2];
                                                parameterData[3] = SDPC->parameterData[3];
                                                parameterDataLength = 4;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_SN_CHANNEL_INDEX:

                                                inputParameters->sourceSN = (((unsigned int)SDPC->parameterData[1])<<8) + SDPC->parameterData[0];
                                                inputParameters->sourceCI = SDPC->parameterData[2];

                                                parameterData[0] = SDPC->parameterData[0];
                                                parameterData[1] = SDPC->parameterData[1];
                                                parameterData[2] = SDPC->parameterData[2];
                                                parameterDataLength = 3;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            case PARAMETER_ADDRESS_INPUT_DATA_CHANNEL_SOURCE_NODE_IDS:

                                                inputParameters->sourceUnitNodeId  = SDPC->parameterData[0];
                                                inputParameters->sourceChannelNodeId = SDPC->parameterData[1];

                                                parameterDataLength = 2;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,inputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_SET_UNIT_PARAMETER);

                                                break;
                                        }
                                        break;
                                    case OUTPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        outputParameters = (OUTPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (SDPC->parameterId)
                                        {
                                            case PARAMETER_ADDRESS_OUTPUT_DATA_CHANNEL_NODE_ID:

                                                outputParameters->nodeId = SDPC->parameterData[0];

                                                parameterData[0] = SDPC->parameterData[0];
                                                parameterDataLength = 1;

                                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                                SEND_PDCP_MESSAGE(currentTxMessage);
                                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                                break;
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,outputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_SET_UNIT_PARAMETER);

                                                break;
                                        }
                                        break;
                                    default :

                                        parameterDataLength = 0;

                                        currentTxMessage = FindEmptyPdcpMessageLocation();
                                        RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                        CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                                        SEND_PDCP_MESSAGE(currentTxMessage);
                                        AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                        break;
                                }

                                break;
                        }
                    }
                    else
                    {
                        parameterDataLength = 0;

                        currentTxMessage = FindEmptyPdcpMessageLocation();
                        RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                        CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                        SEND_PDCP_MESSAGE(currentTxMessage);
                        AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
                    }// end of switch (SDPC->channelIndex)


                    break;
                case PDCP_COMMAND_RESET_UNIT:

                    currentTxMessage = FindEmptyPdcpMessageLocation();
                    RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                    CREATE_RESET_UNIT_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId);
                    SEND_PDCP_MESSAGE(currentTxMessage);
                    AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                    currentTimerValue = GET_CURRENT_TIME();

                    while ((currentTimerValue + 50)>GET_CURRENT_TIME()) {}

                    asm("reset");

                    break;
                case PDCP_COMMAND_CONFIG_SET_BULK_DATA_TRANSFER:

                    CSBDC = (CONFIG_SET_BULK_DATA_COMMAND_MESSAGE *)currentPDCPMessage->data;

                    if (CSBDC->channelIndex == UNIT_CHANNEL_INDEX)
                    {
                        switch (CSBDC->parameterId)
                        {
                            default:
                                currentTxMessage = FindEmptyPdcpMessageLocation();
                                RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                CREATE_CONFIG_SET_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, CSBDC->parameterId, CSBDC->channelIndex, CSBDC->bulkDataSize);
                                SEND_PDCP_MESSAGE(currentTxMessage);
                                AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                break;
                        }
                    }
                    else if (CSBDC->channelIndex <= unit->devInfo.numOfDataChannels)
                    {
                        currentDataChannel = FindDataChannelByChannelIndex(unit, CSBDC->channelIndex);

                        switch (CSBDC->parameterId)
                        {
                            default:

                                switch (currentDataChannel->channel_info.transferType)
                                {
                                    case INPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        inputParameters = (INPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (CSBDC->parameterId)
                                        {
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,inputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_CONFIG_SET_BULK_DATA_TRANSFER);

                                                break;
                                        }
                                        break;
                                    case OUTPUT_DATA_CHANNEL_TRANSFER_TYPE:

                                        outputParameters = (OUTPUT_DATA_PARAMETERS*) currentDataChannel->parameters;

                                        switch (CSBDC->parameterId)
                                        {
                                            default:

                                                ProcessDataChannelSpecificParameters(unit,currentPDCPMessage,outputParameters->parameters,currentDataChannel->dataChannelStructureId,PDCP_COMMAND_CONFIG_SET_BULK_DATA_TRANSFER);

                                                break;
                                        }
                                        break;
                                    default :

                                        currentTxMessage = FindEmptyPdcpMessageLocation();
                                        RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                                        CREATE_CONFIG_SET_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, CSBDC->parameterId, CSBDC->channelIndex, CSBDC->bulkDataSize);
                                        SEND_PDCP_MESSAGE(currentTxMessage);
                                        AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                                        break;
                                }

                                break;
                        }
                    }

                    break;

                case PDCP_COMMAND_BULK_DATA_TRANSFER:

                    if (unit->bulkDataVars.Flag == 1)
                    {
                        StoreBulkDataIntoMemory(unit, currentPDCPMessage);

                        if (unit->bulkDataVars.Ctr >= unit->bulkDataVars.Size)  // If all the bulk data has been transfered...
                        {
                            StoreBulkDataIntoVariable(unit);

                            currentTxMessage = FindEmptyPdcpMessageLocation();
                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                            CREATE_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(currentTxMessage, currentPDCPMessage->nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL);
                            SEND_PDCP_MESSAGE(currentTxMessage);
                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                            free(unit->bulkDataVars.Ptr);

                            unit->bulkDataVars.Flag = 0;
                            unit->bulkDataVars.Ctr  = 0;
                            unit->bulkDataVars.Size = 0;
                            unit->bulkDataVars.Ptr  = NULL_POINTER;
                        }
                    }

                    break;
                default:

                    currentTxMessage = FindEmptyPdcpMessageLocation();
                    RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                    CREATE_UNKNOWN_FUNCTION_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId);
                    SEND_PDCP_MESSAGE(currentTxMessage);
                    AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                    break;

            } // end of switch(UNKN->functionCode)
        }
    } // end of handler for message sent to unit's control nodeId
    else // if message not intended for unit's control nodeId then it is meant for an input data channel
    {
        for (i=1;i <= unit->devInfo.numOfDataChannels; i++)  // loop through to find every data channel listening for this nodeId
        {
            if (i == 1)
            {
                currentDataChannel = unit->headDataChannelList;
            }

            if (currentDataChannel->channel_info.transferType == INPUT_DATA_CHANNEL_TRANSFER_TYPE)
            {
                inputParameters = (INPUT_DATA_PARAMETERS *)currentDataChannel->parameters;

                if ((inputParameters->sourceChannelNodeId == currentPDCPMessage->nodeId)&&(currentDataChannel->channel_info.transferEnableFlag == 1))
                {
                    currentTxMessage = FindEmptyPdcpMessageLocation();
                    RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);

                    memcpy(currentTxMessage,currentPDCPMessage,sizeof(PDCPMESSAGE));

                    memcpy(currentTxMessage->dataArray,currentPDCPMessage->data,currentTxMessage->length);
                    
//                    currentTxMessage->data = (unsigned char*) calloc(currentTxMessage->length,sizeof(unsigned char));
//                    memcpy(currentTxMessage->data,currentPDCPMessage->data,currentTxMessage->length);
                    
                    // If the data channel's message buffer is full, remove the oldest message before adding a new one...
                    if (currentDataChannel->numOfMessages >= currentDataChannel->PDCPBufferSize)
                    {
                        headOfDataChannelMessages = currentDataChannel->headMessage;
                        RemoveMessageFromPDCPMessageListOfDataChannel(currentDataChannel, headOfDataChannelMessages);
                        AppendPdcpMessageToEmptyPdcpMessageList(headOfDataChannelMessages);
                    }

                    AppendMessageToPDCPMessageListOfDataChannel(currentDataChannel,currentTxMessage);
                }
            }

            currentDataChannel = currentDataChannel->next;
        }
    }
} // end of ProcessPDCPMessage


unsigned char IsMessageForThisUnit(UNIT* unit, PDCPMESSAGE* currentPDCPMessage)
{
    unsigned char i;

    DATA_CHANNEL * currentDataChannel;
    INPUT_DATA_PARAMETERS * inputParameters;

    if (currentPDCPMessage->priority == PDCP_PRIORITY_BIND)
    {
        return 0;
    }
    else if ((currentPDCPMessage->nodeId == unit->devInfo.nodeId)&&(currentPDCPMessage->mode == PDCP_MASTER_MESSAGE_MODE))
    {
        return 1;
    }
    else if (currentPDCPMessage->mode != PDCP_MASTER_MESSAGE_MODE)
    {
        if (unit->bindVars.unitBound == 1)
        {
            for (i=1;(i <= (unit->devInfo.numOfDataChannels));i++)
            {
                if (i==1)
                {
                    currentDataChannel = unit->headDataChannelList;
                }

                if (currentDataChannel->channel_info.transferType == INPUT_DATA_CHANNEL_TRANSFER_TYPE)
                {
                    inputParameters = (INPUT_DATA_PARAMETERS*)currentDataChannel->parameters;

                    if (inputParameters->sourceChannelNodeId == currentPDCPMessage->nodeId)
                    {
                        return 1;
                    }
                }

                currentDataChannel = currentDataChannel->next;
            }
        }
        else
        {
            return 0;
        }
    }

    return 0;
}


void AppendMessageToPDCPMessageListOfDataChannel(DATA_CHANNEL   *lnode, PDCPMESSAGE *PDCPMessage)
{
    PDCPMessage->busId = lnode->parent->busId;

    if(lnode->headMessage == NULL_POINTER)
    {
        lnode->headMessage = PDCPMessage;
        PDCPMessage->prev = NULL_POINTER;
    }
    else
    {
        lnode->tailMessage->next = PDCPMessage;
        PDCPMessage->prev = lnode->tailMessage;
    }

    lnode->tailMessage = PDCPMessage;
    PDCPMessage->next = NULL_POINTER;

    lnode->numOfMessages++;
}


void RemoveMessageFromPDCPMessageListOfDataChannel(DATA_CHANNEL *lnode, PDCPMESSAGE *PDCPMessage)
{
   if(PDCPMessage->prev == NULL_POINTER)
   {
      lnode->headMessage = PDCPMessage->next;
   }
   else
   {
      PDCPMessage->prev->next = PDCPMessage->next;
   }

   if(PDCPMessage->next == NULL_POINTER)
   {
      lnode->tailMessage = PDCPMessage->prev;
   }
   else
   {
      PDCPMessage->next->prev = PDCPMessage->prev;
   }

   lnode->numOfMessages--;
}


unsigned char IsInputDataChannelMessageAvailable(DATA_CHANNEL* dataChannel)
{
    if ((dataChannel->numOfMessages == 0 )||(dataChannel->channel_info.transferType == OUTPUT_DATA_CHANNEL_TRANSFER_TYPE))
    {
        return 0;
    }
    else
    {
        return dataChannel->numOfMessages;
    }
}


unsigned char SizeOfInputDataChannelMessage(DATA_CHANNEL* dataChannel)
{
    if ((dataChannel->numOfMessages == 0)||(dataChannel->channel_info.transferType == OUTPUT_DATA_CHANNEL_TRANSFER_TYPE))
    {
        return 0;
    }
    else
    {
        return dataChannel->headMessage->length;
    }
}


void GetDataFromInputDataChannelMessage(DATA_CHANNEL* dataChannel, unsigned char* destination)
{
    PDCPMESSAGE* currentMessage;

    if ((dataChannel->numOfMessages != 0)&&(dataChannel->channel_info.transferType == INPUT_DATA_CHANNEL_TRANSFER_TYPE))
    {
        currentMessage = dataChannel->headMessage;
        memcpy(destination,currentMessage->dataArray,currentMessage->length);
        RemoveMessageFromPDCPMessageListOfDataChannel(dataChannel, currentMessage);
        AppendPdcpMessageToEmptyPdcpMessageList(currentMessage);
    }
}



unsigned char SendDataOnOutputDataChannel(DATA_CHANNEL* dataChannel, unsigned char* origin, unsigned int length)
{
    PDCPMESSAGE currentMessage;
    OUTPUT_DATA_PARAMETERS* outputParameters;

    // Only send the data if the data channel's transfer enable flag is set AND the data channel is actually an output data channel
    if ((dataChannel->channel_info.transferEnableFlag != 0)&&(dataChannel->channel_info.transferType == OUTPUT_DATA_CHANNEL_TRANSFER_TYPE))
    {
        outputParameters = (OUTPUT_DATA_PARAMETERS*)dataChannel->parameters;
        
        currentMessage.busId    = dataChannel->parent->busId;
        currentMessage.priority = PDCP_PRIORITY_HIGH;
        currentMessage.mode     = PDCP_STANDARD_MESSAGE_MODE;
        currentMessage.nodeId   = outputParameters->nodeId;
        currentMessage.length   = length;

        currentMessage.data = (unsigned char*) calloc(currentMessage.length,sizeof(unsigned char));
        memcpy(currentMessage.data,origin,length);

        SEND_PDCP_MESSAGE(&currentMessage);

        free(currentMessage.data);

        return 1;
    }
    else
    {
        return 0;
    }

}

void StoreBulkDataIntoMemory(UNIT *unit, PDCPMESSAGE *PDCPMessage)
{
    memcpy((unit->bulkDataVars.Ptr+unit->bulkDataVars.Ctr),(PDCPMessage->data+2),(unsigned char)(PDCPMessage->length-2));

    unit->bulkDataVars.Ctr = unit->bulkDataVars.Ctr + (PDCPMessage->length-2);
}

