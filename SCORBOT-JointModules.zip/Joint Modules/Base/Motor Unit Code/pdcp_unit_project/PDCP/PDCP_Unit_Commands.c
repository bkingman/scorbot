/*
 * File:   PDCP_Commands.c
 * Author: yveslosier
 *
 * Created on February 18, 2014, 9:59 PM
 */

#include "PDCP_Unit_Commands.h"
#include "Config_PDCP_Unit_Commands.h"

#include <stdlib.h>
#include <string.h>


// ------------------------------------------------------------
// PDCP Message related variables
// ------------------------------------------------------------
//UNIT __attribute__((far)) pdcpMessageArray[MAX_NUM_OF_PDCP_MESSAGES];
PDCPMESSAGE pdcpMessageArray[MAX_NUM_OF_PDCP_MESSAGES];

PDCPMESSAGE *headEmptyPdcpMessageList;
PDCPMESSAGE *tailEmptyPdcpMessageList;
PDCPMESSAGE *headPdcpMessageList;
PDCPMESSAGE *tailPdcpMessageList;
PDCPMESSAGE *desiredPdcpMessage;
//PDCPMESSAGE *pdcpMessageList[MAX_NUM_OF_PDCP_MESSAGES];

unsigned char numOfEmptyPdcpMessageLocations;
unsigned char numOfPdcpMessages;
// ------------------------------------------------------------


//DEBUG: Used in testing only...
//BIND_UNIT_REQUEST_MESSAGE test;



void InitPDCPCommands(void)
{
    PDCP_COMMAND_HARDWARE_CONFIG();
    
    InitPdcpMessageList();
}


void UpdatePDCPCommandsStateMachine(void)
{
    PDCPMESSAGE * newMessageLocation;

    UPDATE_PDCP_HARDWARE_STATE_MACHINES();

    if (PDCP_MESSAGE_AVAILABLE_FROM_HARDWARE_QUEUE())
    {
        newMessageLocation = FindEmptyPdcpMessageLocation();

        if (newMessageLocation != NULL_POINTER)
        {
            RETRIEVE_PDCP_MESSAGE_FROM_HARDWARE_QUEUE(newMessageLocation);
            RemovePdcpMessageFromEmptyPdcpMessageList(newMessageLocation);
            AppendPdcpMessageToPdcpMessageList(newMessageLocation);
        }
        else
        {
            while(1) {}
            // Trap can be placed here to determine if there's not enough
            //  PDCP Message Locations...
        }
    }
}


unsigned char PdcpMessageAvailableInQueue(void)
{
    return (numOfPdcpMessages>0);
}


PDCPMESSAGE * GetPdcpMessageFromQueue(void)
{
    return headPdcpMessageList;
}


void SEND_PDCP_MESSAGE(PDCPMESSAGE * currentPDCPMessage)
{
    SEND_PDCP_MESSAGE_TO_HARDWARE_QUEUE(currentPDCPMessage);
}


void CREATE_UNKNOWN_FUNCTION_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 2;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_RESPONSE_UNKNOWN;
    *(PDCPMessage->data+1)=PDCP_RESPONSE_CODE_FAILURE;

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from Bus Arbitrator after message has been sent
}

void CREATE_BIND_REQUEST_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned int VID, unsigned int PID, unsigned int SN)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_BIND;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 7;
    
    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_COMMAND_BIND_REQUEST;
    *(PDCPMessage->data+1)=(unsigned char)(VID   );
    *(PDCPMessage->data+2)=(unsigned char)(VID>>8);
    *(PDCPMessage->data+3)=(unsigned char)(PID   );
    *(PDCPMessage->data+4)=(unsigned char)(PID>>8);
    *(PDCPMessage->data+5)=(unsigned char)(SN    );
    *(PDCPMessage->data+6)=(unsigned char)(SN >>8);
}

void CREATE_GET_UNIT_PARAMETER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex)
{
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 3;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_COMMAND_GET_UNIT_PARAMETER;
    *(PDCPMessage->data+1)=parameterId;
    *(PDCPMessage->data+2)=channelIndex;

    PDCPMessage->responseExpectedFlag = 1;  // Response expected from unit to Bus Arbitrator after message has been sent
}


void CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 4+length;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_RESPONSE_GET_UNIT_PARAMETER;
    *(PDCPMessage->data+1)=errorCode;
    *(PDCPMessage->data+2)=parameterId;
    *(PDCPMessage->data+3)=channelIndex;

    memcpy((PDCPMessage->data+4),data,length);

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from Bus Arbitrator after message has been sent
}


void CREATE_SET_UNIT_PARAMETER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length)
{
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_MASTER_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 3+length;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_COMMAND_SET_UNIT_PARAMETER;
    *(PDCPMessage->data+1)=parameterId;
    *(PDCPMessage->data+2)=channelIndex;

    memcpy((PDCPMessage->data+3),data,length);

    PDCPMessage->responseExpectedFlag = 1;  // Response expected from unit to Bus Arbitrator after message has been sent
}


void CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned char *data, unsigned int length)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 4+length;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_RESPONSE_SET_UNIT_PARAMETER;
    *(PDCPMessage->data+1)=errorCode;
    *(PDCPMessage->data+2)=parameterId;
    *(PDCPMessage->data+3)=channelIndex;
    
    memcpy((PDCPMessage->data+4),data,length);

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from Bus Arbitrator after message has been sent
}


void CREATE_BEACON_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_HIGH;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 1;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_COMMAND_NODE_BEACON;
}

void CREATE_RESET_UNIT_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId)
{
    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 2;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_RESPONSE_RESET_UNIT;
    *(PDCPMessage->data+1)=PDCP_RESPONSE_CODE_SUCCESSFUL;

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from Bus Arbitrator after unit message has been sent
}


void CREATE_CONFIG_GET_BULK_DATA_TRANSFER(PDCPMESSAGE * PDCPMessage, PDCPMESSAGE * currentPDCPMessage)
{
    GET_UNIT_PARAMETER_RESPONSE_MESSAGE * GDPR;

    PDCPMessage->busId    = currentPDCPMessage->busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = currentPDCPMessage->nodeId;
    PDCPMessage->length   = 3;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    GDPR = (GET_UNIT_PARAMETER_RESPONSE_MESSAGE *)currentPDCPMessage->data;

    *(PDCPMessage->data+0)=PDCP_COMMAND_CONFIG_GET_BULK_DATA_TRANSFER;
    *(PDCPMessage->data+1)=GDPR->parameterId;
    *(PDCPMessage->data+2)=GDPR->channelIndex;

    PDCPMessage->responseExpectedFlag = 1;  // Response expected from Bus Arbitrator after unit message has been sent
}


void CREATE_CONFIG_SET_BULK_DATA_TRANSFER(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned int length)
{
    CONFIG_SET_BULK_DATA_COMMAND_MESSAGE * CSBDC;

    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 5;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    CSBDC = (CONFIG_SET_BULK_DATA_COMMAND_MESSAGE *)PDCPMessage->data;

    CSBDC->functionCode = PDCP_COMMAND_CONFIG_SET_BULK_DATA_TRANSFER;
    CSBDC->parameterId  = parameterId;
    CSBDC->channelIndex = channelIndex;
    CSBDC->bulkDataSize = length;

    PDCPMessage->responseExpectedFlag = 1;  // Response expected from Bus Arbitrator after unit message has been sent
}


void CREATE_CONFIG_SET_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char busId, unsigned char nodeId, unsigned char errorCode, unsigned char parameterId, unsigned char channelIndex, unsigned int length)
{
    CONFIG_SET_BULK_DATA_RESPONSE_MESSAGE * CSBDR;

    PDCPMessage->busId    = busId;
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 6;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    CSBDR = (CONFIG_SET_BULK_DATA_RESPONSE_MESSAGE *)PDCPMessage->data;

    CSBDR->functionCode = PDCP_RESPONSE_CONFIG_SET_BULK_DATA_TRANSFER;
    CSBDR->responseCode = errorCode;
    CSBDR->parameterId  = parameterId;
    CSBDR->channelIndex = channelIndex;
    CSBDR->bulkDataSize = length;

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from Bus Arbitrator after unit message has been sent

}


void CREATE_BULK_DATA_TRANSFER_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char parameterId, unsigned char channelIndex, unsigned char packetId, unsigned char *data, unsigned int dataLength)
{
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 2 + dataLength;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_COMMAND_BULK_DATA_TRANSFER;
    *(PDCPMessage->data+1)=packetId;

    memcpy((PDCPMessage->data+2),data,dataLength);

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from unit to Bus Arbitrator after message has been sent
}


void CREATE_BULK_DATA_TRANSFER_RESPONSE_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char responseCode)
{
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = 2;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));

    *(PDCPMessage->data+0)=PDCP_RESPONSE_BULK_DATA_TRANSFER;
    *(PDCPMessage->data+1)=responseCode;

    PDCPMessage->responseExpectedFlag = 0;  // Response not expected from unit to Bus Arbitrator after message has been sent    
}


void CREATE_STANDARD_PASSTHROUGH_MESSAGE(PDCPMESSAGE * PDCPMessage, unsigned char nodeId, unsigned char *data, unsigned int length, unsigned char responseExpectedFlag)
{
    PDCPMessage->priority = PDCP_PRIORITY_NORMAL;
    PDCPMessage->mode     = PDCP_STANDARD_MESSAGE_MODE;
    PDCPMessage->nodeId   = nodeId;
    PDCPMessage->length   = length;

    PDCPMessage->data = (unsigned char*) calloc(PDCPMessage->length,sizeof(unsigned char));
    memcpy(PDCPMessage->data,data,PDCPMessage->length);

    PDCPMessage->responseExpectedFlag = responseExpectedFlag;  // Response expected from unit to Bus Arbitrator after message has been sent
}


// ------------------------------------------------------------
// PDCP Message related functions
// ------------------------------------------------------------
void InitPdcpMessageList(void)
{
   unsigned char i;
   PDCPMESSAGE * currentPdcpMessage = pdcpMessageArray;

   memset(pdcpMessageArray,0,sizeof(*pdcpMessageArray));

   numOfEmptyPdcpMessageLocations = 0;

   for (i=0;i<MAX_NUM_OF_PDCP_MESSAGES;i++)
   {
       // Placing dummy val in memory to avoid issues on startup
       //  (where in the following step, the function will try to
       //   'free' the data memory locations.
       currentPdcpMessage->data = (unsigned char*) calloc(1,sizeof(unsigned char));

       AppendPdcpMessageToEmptyPdcpMessageList(currentPdcpMessage);
       currentPdcpMessage++;
   }
}


PDCPMESSAGE * FindEmptyPdcpMessageLocation(void)
{
    return headEmptyPdcpMessageList;
}


PDCPMESSAGE * FindPdcpMessageByNodeId(unsigned int nodeId)
{
   unsigned char i;
   PDCPMESSAGE * currentPdcpMessage;

   currentPdcpMessage = headPdcpMessageList;

   for (i=0;i<numOfPdcpMessages;i++)
   {
      if (currentPdcpMessage->nodeId==nodeId)
      {
         return currentPdcpMessage;
      }
      currentPdcpMessage = currentPdcpMessage->next;
   }
   return NULL_POINTER;
}


void AppendPdcpMessageToEmptyPdcpMessageList(PDCPMESSAGE *lnode)
{
   free(lnode->data);

   memset(lnode,0,sizeof(*lnode));

   if(headEmptyPdcpMessageList == NULL_POINTER)
   {
      headEmptyPdcpMessageList = lnode;
      lnode->prev = NULL_POINTER;
   }
   else
   {
      tailEmptyPdcpMessageList->next = lnode;
      lnode->prev = tailEmptyPdcpMessageList;
   }

   tailEmptyPdcpMessageList = lnode;
   lnode->next = NULL_POINTER;

   numOfEmptyPdcpMessageLocations++;
}


void InsertPdcpMessageToEmptyPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *after)
{
   free(lnode->data);

   memset(lnode,0,sizeof(*lnode));

   lnode->next = after->next;
   lnode->prev = after;

   if(after->next != NULL_POINTER)
   {
      after->next->prev = lnode;
   }
   else
   {
      tailEmptyPdcpMessageList = lnode;
   }

   after->next = lnode;

   numOfEmptyPdcpMessageLocations++;
}


void RemovePdcpMessageFromEmptyPdcpMessageList(PDCPMESSAGE *lnode)
{
   if(lnode->prev == NULL_POINTER)
   {
      headEmptyPdcpMessageList = lnode->next;
   }
   else
   {
      lnode->prev->next = lnode->next;
   }

   if(lnode->next == NULL_POINTER)
   {
      tailEmptyPdcpMessageList = lnode->prev;
   }
   else
   {
      lnode->next->prev = lnode->prev;
   }

   numOfEmptyPdcpMessageLocations--;
}


void AppendPdcpMessageToPdcpMessageList(PDCPMESSAGE *lnode)
{
   if(headPdcpMessageList == NULL_POINTER)
   {
      headPdcpMessageList = lnode;
      lnode->prev = NULL_POINTER;
   }
   else
   {
      tailPdcpMessageList->next = lnode;
      lnode->prev = tailPdcpMessageList;
   }

   tailPdcpMessageList = lnode;
   lnode->next = NULL_POINTER;

   numOfPdcpMessages++;
}


void InsertPdcpMessageBeforeToPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *before)
{
   lnode->prev = before->prev;
   lnode->next = before;

   if(before->prev != NULL_POINTER)
   {
      before->prev->next = lnode;
   }
   else
   {
      headPdcpMessageList = lnode;
   }

   before->prev = lnode;

   numOfPdcpMessages++;
}


void InsertPdcpMessageAfterToPdcpMessageList(PDCPMESSAGE *lnode, PDCPMESSAGE *after)
{
   lnode->next = after->next;
   lnode->prev = after;

   if(after->next != NULL_POINTER)
   {
      after->next->prev = lnode;
   }
   else
   {
      tailPdcpMessageList = lnode;
   }

   after->next = lnode;

   numOfPdcpMessages++;
}


void RemovePdcpMessageFromPdcpMessageList(PDCPMESSAGE *lnode)
{
   if(lnode->prev == NULL_POINTER)
   {
      headPdcpMessageList = lnode->next;
   }
   else
   {
      lnode->prev->next = lnode->next;
   }

   if(lnode->next == NULL_POINTER)
   {
      tailPdcpMessageList = lnode->prev;
   }
   else
   {
      lnode->next->prev = lnode->prev;
   }

   numOfPdcpMessages--;
}
// ------------------------------------------------------------


unsigned char MAX_DATA_PAYLOAD_PER_MESSAGE(void)
{
    return MAX_DATA_PAYLOAD_PER_HARDWARE_MESSAGE();
}


unsigned char MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_SIZE(void)
{
    return MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE();
}


unsigned char MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_SIZE(void)
{
    return MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_HARDWARE_SIZE();
}


unsigned char MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_SIZE(void)
{
    return MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_HARDWARE_SIZE();
}


void CONFIG_MASK_AND_FILTER(unsigned char nodeId,unsigned char unitBoundFlag)
{
    ConfigHardwareMaskAndFilter(nodeId,unitBoundFlag);
}







