/* 
 * File:   PDCP.h
 * Author: yveslosier
 *
 * Created on February 18, 2014, 10:25 PM
 */

#ifndef PDCP_H
#define	PDCP_H

#ifdef	__cplusplus
extern "C" {
#endif



typedef struct pdcpMessage PDCPMESSAGE;

struct pdcpMessage
{
   unsigned char priority;  // PDCP message priority
   unsigned char mode;      // PDCP message mode
   unsigned char nodeId;    // PDCP message nodeId

   unsigned char *data;  // Pointer to PDCP data payload
   unsigned int length;  // length of PDCP data payload (in terms of # of bytes)

   unsigned char busId;     // variable used to store the Hardware Id in order to identify where the message originated
   unsigned char responseExpectedFlag;  // variable used to indicate if the unit expects a reply for the given message

   unsigned char dataArray[8];
   
   PDCPMESSAGE *prev;  // pointer for previous message in double linked list
   PDCPMESSAGE *next;  // pointer for next message in double linked list
};




#ifndef NULL_POINTER
   #define NULL_POINTER 0
#endif


#ifdef	__cplusplus
}
#endif

#endif	/* PDCP_H */

