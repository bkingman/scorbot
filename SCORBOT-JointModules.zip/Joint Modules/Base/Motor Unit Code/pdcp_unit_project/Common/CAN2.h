/*
 * File:   CAN2.h
 * Author: yveslosier
 *
 * Created on January 26, 2011, 11:03 AM
 *
 * REVISION HISTORY:
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Author		Date      	Comments on this revision
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Y. Losier            26/01/11        First release of source file
 *
 * ADDITIONAL NOTES:
 *
 */

#ifndef __CAN2_H__
#define __CAN2_H__ 

#if defined(__dsPIC33F__)
#include "p33fxxxx.h"
#elif defined(__PIC24H__)
#include "p24hxxxx.h"
#endif


#include "CANcommon.h"
//#include "Main.h"


//---------------------
//ADDED_YGL
#include "Config_Micro.h"
//---------------------



#ifndef BITRATE_CAN2
   #define BITRATE_CAN2 1000000  
#endif


// CAN Baud Rate Configuration
#define FC_CAN2      16000000
#define NTQ_CAN2       8        // 8 Time Quanta in a Bit Time
#define BRP_VAL_CAN2   ((FC_CAN2/(2*NTQ_CAN2*BITRATE_CAN2))-1)



// CAN Message Buffer Configuration
#define  ECAN2_MSG_BUF_LENGTH 	32
typedef unsigned int ECAN2MSGBUF [ECAN2_MSG_BUF_LENGTH][8];	

#define CAN2_FILTER 0x000
#define CAN2_MASK 0x000 //  Clearing the mask such that the unit listens to all messages on the CAN1 bus


//---------------------------------------------------------------
// Variable Declarations
//---------------------------------------------------------------
extern ECAN2MSGBUF  ecan2msgBuf __attribute__((space(dma),aligned(ECAN2_MSG_BUF_LENGTH*16)));

//-- End of Variable Declarations -------------------------------


static inline void CAN2_ENABLE() 	{CAN2_Enable_Pin=1;}
static inline void CAN2_DISABLE()   	{CAN2_Enable_Pin=0;}
static inline void CAN2_HIGHSPEED()	{CAN2_Standby_Pin=0;}
static inline void CAN2_STANDBY()	{CAN2_Standby_Pin=1;}



//---------------------------------------------------------------
// Function Declarations
//---------------------------------------------------------------
extern void ecan2WriteRxAcptFilter(int n, long identifier, unsigned int exide,unsigned int bufPnt,unsigned int maskSel);
extern void ecan2WriteRxAcptMask(int m, long identifierMask, unsigned int mide,unsigned int exide);

extern void ecan2WriteTxMsgBufId(unsigned int buf, long txIdentifier, unsigned int ide, unsigned int remoteTransmit);
extern void ecan2WriteTxMsgBufData(unsigned int buf, unsigned int dataLength, unsigned int data1, unsigned int data2, unsigned int data3, unsigned int data4);

extern void CAN2_putId(unsigned int buf, long txIdentifier);
extern void CAN2_putBufData(unsigned int buf, CANdata* can1Data);
extern void CAN2_sendData(long address, CANdata* pCan1Data);

extern unsigned char CAN2TXBusy(void);

extern void ecan2DisableRXFilter(int n);


extern void __attribute__((interrupt, no_auto_psv))_C1Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv)) _DMA1Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv)) _DMA3Interrupt(void);

extern void CAN2PinConfig(void);
extern void CAN2ModuleConfig(void);
extern void ecan2init(long canFilter, long canMask);
extern void dma1init(void);
extern void dma3init(void);

extern void ClrRxFullFlagECAN2(unsigned char u8_bufNum);
extern unsigned char GetRxFullFlagECAN2(unsigned char u8_bufNum);
extern void ClrRxFullOvfFlagsECAN2(void);
//-- End of Function Declarations -------------------------------


#endif

