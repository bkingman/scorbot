/*
 * File:   CANmessage.h
 * Author: yveslosier
 *
 * Created on January 24, 2011, 11:34 AM
 *
 * REVISION HISTORY:
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Author		Date      	Comments on this revision
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Y. Losier            24/01/11        First release of source file
 *
 * ADDITIONAL NOTES:
 *
 */

#ifndef __CANMESSAGE_H__
#define __CANMESSAGE_H__

#include "CAN1.h"
#include "CAN2.h"

//---------------------
#include "PDCP.h"
#include "Config_Micro.h"
//---------------------

#define CAN1_BINDING_MASK  0x7FF //  Setting the mask such that the unit only listens to specific messages from the bus arbitrator
#define CAN1_STANDARD_MASK 0x1FF //  Setting the mask such that the unit listens to any intended messages from the bus arbitrator on the CAN bus
#define CAN1_OPEN_MASK 0x000     //  Setting the mask such that the unit listens to all messages on the CAN bus


//------------------------------------------------------------------
// CAN Message Structure, Function and Variable Declaration
//------------------------------------------------------------------
#define NUM_OF_PRIORITY_LEVELS 3
#define MAX_NUM_CAN_MESSAGES 160
#define MAX_NUM_CAN_RX_MESSAGES 128
#define MAX_NUM_CAN_TX_MESSAGES (MAX_NUM_CAN_MESSAGES-MAX_NUM_CAN_RX_MESSAGES)

#ifndef NULL_POINTER
   #define NULL_POINTER 0
#endif


typedef struct canMessage CANMESSAGE;

struct canMessage
{
   unsigned char priority;
   unsigned char mode;
   unsigned char nodeId;
   unsigned char length;
   unsigned char canBusId;
   unsigned char controlNodeMessageFlag;

   union
   {
      unsigned char data8[8];
      unsigned int data16[4];
   };
   CANMESSAGE *prev;
   CANMESSAGE *next;
};



//------------------------------------------------------------------

typedef enum {MODULE_IDLE=0x00,MODULE_PROCESSING} CANMESSAGEFSM;
extern CANMESSAGEFSM CAN_MESSAGE_PROCESSOR_ENGINE_STATE;

//------------------------------------------------------------------


extern CANMESSAGE __attribute__((far)) canMessageArray[MAX_NUM_CAN_MESSAGES];


extern CANMESSAGE *headCanRxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *tailCanRxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *headCan1TxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *tailCan1TxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *headCan2TxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *tailCan2TxMessageList[NUM_OF_PRIORITY_LEVELS];
extern CANMESSAGE *headAvailableMessageLocationList;
extern CANMESSAGE *tailAvailableMessageLocationList;
extern CANMESSAGE *desiredQueryCanMessage;


extern unsigned char numOfCan2TxMessages[NUM_OF_PRIORITY_LEVELS];
extern unsigned char totalNumOfCan1TxMessages;
extern unsigned char totalNumOfCan2TxMessages;
extern unsigned char numOfAvailableMessageLocations;

              
extern void InitCanMessageLists(void);
extern CANMESSAGE * FindAvailableMessageLocation(void);
extern CANMESSAGE * FindMessageByNodeId(unsigned char nodeId);

extern void AppendMessageToCanRxMessageList(CANMESSAGE *lnode);
extern void InsertMessageToCanRxMessageList(CANMESSAGE *lnode, CANMESSAGE *after);
extern void RemoveMessageFromCanRxMessageList(CANMESSAGE *lnode);

extern void AppendMessageToCan1TxMessageList(CANMESSAGE *lnode);
extern void InsertMessageToCan1TxMessageList(CANMESSAGE *lnode, CANMESSAGE *after);
extern void RemoveMessageFromCan1TxMessageList(CANMESSAGE *lnode);

extern void AppendMessageToCan2TxMessageList(CANMESSAGE *lnode);
extern void InsertMessageToCan2TxMessageList(CANMESSAGE *lnode, CANMESSAGE *after);
extern void RemoveMessageFromCan2TxMessageList(CANMESSAGE *lnode);


extern void AppendMessageToAvailableMessageLocationList(CANMESSAGE *lnode);
extern void InsertMessageToAvailableMessageLocationList(CANMESSAGE *lnode, CANMESSAGE *after);
extern void RemoveMessageFromAvailableMessageLocationList(CANMESSAGE *lnode);

extern unsigned char AddMessageToCanRxMessageList(CANMESSAGE *lnode);
extern unsigned char RemoveMessageFromCanRxMessageListByNodeId(unsigned char nodeId);
extern unsigned char InsertCan1MessageInQueues(unsigned char index);
extern unsigned char InsertCan2MessageInQueues();

extern unsigned char AddCan1TxMessageToQueue(unsigned char priority, unsigned char mode, unsigned char nodeId, CANdata data);
extern unsigned char AddCan2TxMessageToQueue(unsigned char priority, unsigned char mode, unsigned char nodeId, CANdata data);
extern unsigned char AddCanTxMessageToControlNodeQueue(unsigned char priority, unsigned char mode, unsigned char nodeId, CANdata canData);


unsigned int createSID(unsigned char priority, unsigned char mode, unsigned char nodeId);




extern void ProcessPDCPMessage(CANMESSAGE *currentMessage);
extern void CAN1SendNextMessage(CANMESSAGE *currentMessage);
extern void CAN2SendNextMessage(CANMESSAGE *currentMessage);

extern void UpdateCANProcessEngineStateMachine(void);


void ConvertCanToPDCP(PDCPMESSAGE * newPDCPMessage, CANMESSAGE * desiredCanMessage);
void ADD_PDCP_MESSAGE_TO_CAN_TX_QUEUE(PDCPMESSAGE * PDCPMessage);
unsigned char GET_PDCP_MESSAGE_FROM_CAN_RX_QUEUE(PDCPMESSAGE * messageLocation);

void ConfigCanHardware(void);


#define CAN_MAX_DATA_PAYLOAD_PER_MESSAGE 8
#define CAN_MAX_GET_UNIT_PARAMETER_FUNCTION_DATA_SIZE (CAN_MAX_DATA_PAYLOAD_PER_MESSAGE - 4)
#define CAN_MAX_SET_UNIT_PARAMETER_FUNCTION_DATA_SIZE (CAN_MAX_DATA_PAYLOAD_PER_MESSAGE - 4)
#define CAN_MAX_BULK_DATA_TRANSFER_FUNCTION_DATA_SIZE   (CAN_MAX_DATA_PAYLOAD_PER_MESSAGE - 2)


//-- End of CAN Message Structure, Function and Variable Declaration ------

#endif


