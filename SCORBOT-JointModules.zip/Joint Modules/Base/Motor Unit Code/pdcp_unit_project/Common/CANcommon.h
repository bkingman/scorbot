/*
 * File:   CANcommon.h
 * Author: yveslosier
 *
 * Created on January 26, 2011, 9:23 AM
 *
 * REVISION HISTORY:
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Author		Date      	Comments on this revision
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Y. Losier            26/01/11        First release of source file
 *
 * ADDITIONAL NOTES:
 *
 */

#ifndef __CANCOMMON_H__
#define __CANCOMMON_H__ 

#if defined(__dsPIC33F__)
#include "p33fxxxx.h"
#elif defined(__PIC24H__)
#include "p24hxxxx.h"
#endif


#define CAN_MSG_DATA	0x01 // message type 
#define CAN_MSG_RTR     0x02 // data or RTR
#define CAN_FRAME_EXT	0x03 // Frame type
#define CAN_FRAME_STD	0x04 // extended or standard

// message structure in RAM
typedef struct
{
   // keep track of the buffer status
   unsigned char buffer_status;
   
   // RTR message or data message
   unsigned char message_type;
   
   // frame type extended or standard
   unsigned char frame_type;
   
   // buffer being used to reference the message
   unsigned char buffer;
   
   // 29 bit id max of 0x1FFF FFFF
   // 11 bit id max of 0x7FF
   unsigned long id;
   
   // message data
   union
   {
      unsigned char data[8];
      unsigned int data16[4];
   };

   // received message data length
   unsigned char data_length;
}mID;

typedef struct
{
   unsigned int length;

   union
   {
      unsigned int UI16[4];
      unsigned char UI8[8];
   };
}CANdata;

extern CANdata canDataBuffer; // Define Outgoing Message Variable using CANdata Message Structure

#endif
