

#ifndef __I2C_H__
#define __I2C_H__

extern unsigned char slaveAddress;
extern unsigned char readControlByte;
extern unsigned char writeControlByte;

extern unsigned int InitI2C(void);
extern unsigned int ACKStatus(void);
extern unsigned int NotAckI2C(void);
extern unsigned int getsI2C(unsigned char *rdptr, unsigned char Length);
extern unsigned int getI2C(void);
extern unsigned int LDByteWriteI2C(unsigned char ControlByte, unsigned char LowAdd, unsigned char data);
extern unsigned int LDByteReadI2C(unsigned char ControlByte, unsigned char Address, unsigned char *Data, unsigned char Length);

extern void UpdateBarGraph(unsigned int value);

#endif



