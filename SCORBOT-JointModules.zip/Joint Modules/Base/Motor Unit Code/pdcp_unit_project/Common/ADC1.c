/*
 * File:   ADC1.c
 * Author: yveslosier
 *
 * Created on May 23, 2014, 10:50 PM
 */


#include "ADC1.h"

unsigned int  ain3Buff[SAMP_BUFF_SIZE];
unsigned int  ain4Buff[SAMP_BUFF_SIZE];

int  scanCounter=0;
int  sampleCounter=0;


/*=============================================================================
ADC INITIALIZATION FOR CHANNEL SCAN
=============================================================================*/
void InitAdc1(void)
{
    AD1CON1bits.FORM   = 0;		// Data Output Format: Unsigned Integer
    AD1CON1bits.SSRC   = 0;		// Sample Clock Source: Clear Sample bit to start conversion
    AD1CON1bits.ASAM   = 1;		// ADC Sample Control: Sampling begins immediately after conversion
    AD1CON1bits.AD12B  = 1;		// 12-bit ADC operation

    AD1CON2bits.CSCNA = 1;		// Scan Input Selections for CH0+ during Sample A bit
    AD1CON2bits.CHPS  = 0;		// Converts CH0

    AD1CON3bits.ADRC = 0;		// ADC Clock is derived from Systems Clock
    AD1CON3bits.ADCS = 63;		// ADC Conversion Clock Tad=Tcy*(ADCS+1)= (1/16M)*64 = 4us (250Khz)
                                                                  // ADC Conversion Time for 12-bit Tc=12*Tab = 48us

    AD1CON2bits.SMPI    = (NUM_CHS2SCAN-1);	// 4 ADC Channel is scanned

    //AD1CSSL: A/D Input Scan Selection Register

    AD1CSSLbits.CSS4=1;			// Enable AN4 for channel scan
    //AD1CSSLbits.CSS5=1;			// Enable AN5 for channel scan

    _TRISB2= 1;  // input i/o
    //_TRISB3= 1;  // input i/o

    //AD1PCFGH/AD1PCFGL: Port Configuration Register
    //AD1PCFGL=0xFFFF;
    _PCFG4 = 0;		// AN4 as Analog Input
    //_PCFG5 = 0;		// AN5 as Analog Input

    IFS0bits.AD1IF = 0;			// Clear the A/D interrupt flag bit
    IEC0bits.AD1IE = 1;			// Enable A/D interrupt
    AD1CON1bits.ADON = 1;		// Turn on the A/D converter
}



/*=============================================================================  
ADC INTERRUPT SERVICE ROUTINE
=============================================================================*/
void __attribute__((interrupt, no_auto_psv)) _ADC1Interrupt(void)
{

    switch (scanCounter)
    {
        case 0:
                ain3Buff[sampleCounter]=ADC1BUF0;
                break;

        case 1:
                ain4Buff[sampleCounter]=ADC1BUF0;
                break;

        default:
                break;
    }

   scanCounter++;
   if(scanCounter==NUM_CHS2SCAN)
   {
      scanCounter=0;
      sampleCounter++;
   }

   if(sampleCounter==SAMP_BUFF_SIZE)
   {
      sampleCounter=0;
   }   

   IFS0bits.AD1IF = 0;		// Clear the ADC1 Interrupt Flag
}



