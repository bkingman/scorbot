/*
 * File:   ADC1.c
 * Author: yveslosier
 *
 * Created on May 23, 2014, 10:37 PM
 */

#ifndef __ADC1_H__
#define __ADC1_H__


#include "p33fxxxx.h"


#define  SAMP_BUFF_SIZE     1   // Size of the input buffer per analog input
#define  NUM_CHS2SCAN       1   // Number of channels enabled for channel scan

extern unsigned int  ain3Buff[SAMP_BUFF_SIZE];
extern unsigned int  ain4Buff[SAMP_BUFF_SIZE];

extern int  scanCounter;
extern int  sampleCounter;


extern void InitAdc1(void);
extern void __attribute__((__interrupt__)) _ADC1Interrupt(void);


#endif




