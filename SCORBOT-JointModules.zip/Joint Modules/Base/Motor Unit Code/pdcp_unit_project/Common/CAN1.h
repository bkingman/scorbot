/*
 * File:   CAN1.h
 * Author: yveslosier
 *
 * Created on January 25, 2011, 3:16 PM
 *
 * REVISION HISTORY:
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Author		Date      	Comments on this revision
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Y. Losier            25/01/11        First release of source file
 *
 * ADDITIONAL NOTES:
 *
 */

#ifndef __CAN1_H__
#define __CAN1_H__ 

#if defined(__dsPIC33F__)
#include "p33fxxxx.h"
#elif defined(__PIC24H__)
#include "p24hxxxx.h"
#endif


#include "CANcommon.h"

//---------------------
//ADDED_YGL
#include "Config_Micro.h"
//---------------------


#ifndef BITRATE_CAN1
   #define BITRATE_CAN1 1000000
#endif


// CAN Baud Rate Configuration
#define FC_CAN1      16000000
#define NTQ_CAN1       8        // 8 Time Quanta in a Bit Time
#define BRP_VAL_CAN1   ((FC_CAN1/(2*NTQ_CAN1*BITRATE_CAN1))-1)



// CAN Message Buffer Configuration
#define  ECAN1_MSG_BUF_LENGTH 	32
typedef unsigned int ECAN1MSGBUF [ECAN1_MSG_BUF_LENGTH][8];

#define CAN1_FILTER 0x000
#define CAN1_MASK 0x000 //  Clearing the mask such that the unit listens to all messages on the CAN1 bus


//---------------------------------------------------------------
// Variable Declarations
//---------------------------------------------------------------
extern ECAN1MSGBUF  ecan1msgBuf __attribute__((space(dma),aligned(ECAN1_MSG_BUF_LENGTH*16)));

//-- End of Variable Declarations -------------------------------



//---------------------------------------------------------------
// Function Declarations
//---------------------------------------------------------------
extern void ecan1WriteRxAcptFilter(int n, long identifier, unsigned int exide,unsigned int bufPnt,unsigned int maskSel);
extern void ecan1WriteRxAcptMask(int m, long identifierMask, unsigned int mide,unsigned int exide);

extern void ecan1WriteTxMsgBufId(unsigned int buf, long txIdentifier, unsigned int ide, unsigned int remoteTransmit);
extern void ecan1WriteTxMsgBufData(unsigned int buf, unsigned int dataLength, unsigned int data1, unsigned int data2, unsigned int data3, unsigned int data4);

extern void CAN1_putId(unsigned int buf, long txIdentifier);
extern void CAN1_putBufData(unsigned int buf, CANdata* can1Data);
extern void CAN1_sendData(long address, CANdata* pCan1Data);

extern unsigned char CAN1TXBusy(void);

extern void ecan1DisableRXFilter(int n);

extern void __attribute__((interrupt, no_auto_psv))_C1Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv))_DMA0Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv))_DMA2Interrupt(void);

extern void CAN1PinConfig(void);
extern void CAN1ModuleConfig(void);
extern void ecan1init(long canFilter, long canMask);
extern void dma0init(void);
extern void dma2init(void);

extern void ClrRxFullFlagECAN1(unsigned char u8_bufNum);
extern unsigned char GetRxFullFlagECAN1(unsigned char u8_bufNum);
extern void ClrRxFullOvfFlagsECAN1(void);

extern void UpdateCAN1TxStateMachine(void);
extern void UpdateCAN1RxStateMachine(void);

//-- End of Function Declarations -------------------------------


static inline void CAN1_ENABLE()       {CAN1_Enable_Pin=1;}
static inline void CAN1_DISABLE()      {CAN1_Enable_Pin=0;}
static inline void CAN1_HIGHSPEED()    {CAN1_Standby_Pin=0;}
static inline void CAN1_STANDBY()      {CAN1_Standby_Pin=1;}

#endif

