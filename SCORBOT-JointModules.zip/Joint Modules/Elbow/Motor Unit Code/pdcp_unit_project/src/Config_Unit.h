/* 
 * File:   Config_Unit.h
 * Author: Yves
 *
 * Created on July 1, 2014, 1:11 AM
 */

#ifndef CONFIG_PDCP_Unit_H
#define	CONFIG_PDCP_Unit_H

#ifdef	__cplusplus
extern "C" {
#endif

// Elbow Variables
#define VENDOR_ID        01 // 0x0001
#define PRODUCT_ID       17 // 0x0011
#define SERIAL_NUMBER    03 // NOTE: MAKE SURE THIS IS CHANGED FOR EACH NEW UNIT!!   YL

    
    
#define FIRMWARE_VERSION        1  // 1st version of software
#define HARDWARE_VERSION        1  // 1st version of hardware
#define UNIT_TYPE               1  // Arbitrary at this point
#define UNIT_PROFILE            1  // Arbitrary at this point
#define INPUT_CHANNEL_TYPE      1  // Arbitrary at this point
#define INPUT_CHANNEL_PROFILE   1  // Arbitrary at this point
#define OUTPUT_CHANNEL_TYPE     1  // Arbitrary at this point
#define OUTPUT_CHANNEL_PROFILE  1  // Arbitrary at this point

// Defining an Id for each different type of data channels
#define SETPOINT_DATA_CHANNEL 1
#define POSITION_DATA_CHANNEL 2

// Define data channel specific parameters for Joint Angle channel
#define MAX_POSITION 32
#define MIN_POSITION 33
#define MAX_VELOCITY 34
#define MIN_VELOCITY 35 //... and so on....

// Define max size of averaging window for data channels
#define MAX_AVERAGING_WINDOW_SIZE 16

// Define general structure for storing data from data channels
typedef struct dataInfo DATA_INFO;

struct dataInfo
{
    unsigned int value;  // current data channel value
    unsigned int rawData[MAX_AVERAGING_WINDOW_SIZE];  // raw data value
    unsigned int idx;  // index for rawData array
};


typedef struct genericData SETPOINT_DATA;
typedef struct genericData CURRENT_DATA;

struct genericData
{
    DATA_INFO     data;
    unsigned int  sizeOfAveragingWindow;
};


// Declaring function prototypes for initialization of unit and data channels
void InitUnit(UNIT* newUnit);
void InitDataChannel(DATA_CHANNEL* newDataChannel, unsigned char ChannelIndex);

// Declaring function prototype for the function call that handles unit and data channel specific parameters (i.e. non PDCP generic parameters).
void ProcessDataChannelSpecificParameters(UNIT* unit, PDCPMESSAGE* pdcpMessage, void* parameters, unsigned char parameterStructureId, unsigned char functionCode);

// Declaring function prototype for bulk data transfer handling
void StoreBulkDataIntoVariable(UNIT *unit);

// Declaring helper functions for LED Display data handling
void UpdateAverageValue(SETPOINT_DATA* setpointParameters);
unsigned int UpdateSetpointVariables(DATA_CHANNEL* in1, unsigned int* incomingData);

#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_PDCP_Unit_H */

