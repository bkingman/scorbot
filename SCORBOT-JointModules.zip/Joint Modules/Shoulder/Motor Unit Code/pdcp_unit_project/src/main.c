/* 
 * File:   main.c
 * Author: Yves
 * Motor control: Brandon Kingman
 *
 * Created for SCORBOT ER-V senior Sept 2017 - April 2018
 */

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include <stdio.h>
#include <stdlib.h>

#include "p33Fxxxx.h"

#include "PDCP_Unit_Commands.h"
#include "PDCP_Unit_Stack.h"
#include "Config_Unit.h"

#include "Config_Micro.h"

#include "OC.h"

unsigned char value_x, value_y;
unsigned char dataArrayBuffer[8];
unsigned long currentTimeVal;
unsigned int  currentSetpoint1;
unsigned int  currentSetpoint2;


UNIT* myUnit;       // Pointer for the MEC14 Workshop Board Unit
DATA_CHANNEL* in1;  // Pointer for the input data channel (LED Display)
DATA_CHANNEL* out1; // Pointer for the output data channel (Joystick X-axis)
DATA_CHANNEL* out2; // Pointer for the output data channel (Joystick Y-axis)

DATA_CHANNEL* in2;  // Pointer for the input data channel (Test)


//Variable Declaration
char speed = 50;
char dirtoggle = 1;
char HomePosition = 0;
char inc = 2;

// Base variables
//Conversion from degrees to steps
char baseStepConvert = 36; //elbow step conversion

unsigned char data = 0;
char dataFlag = 0;
int posCountOffset = 10000;
int baseStep;
char safeRange = 15;

//Movement Request
unsigned char* uartBufferPtr;
char uartIndex;

// PID controller
double Kp = 5; 
double Ki = 0;
double Kd = 0;
float lastError = 0;
int16_t error = 0;
int16_t changeError = 0;
int32_t totalError = 0;
float pidTerm = 0;
float pidTermScaled = 0;
int8_t pidDir = 0;
int8_t lastPidDir = 0;




// Declaring functino prototype any Unit-specific control/actions desired by the designer
void UpdateUnitFunctions(void);
void UpdateMotorControl(void);

/*
 * 
 */
int main(int argc, char** argv)
{
    // Create Unit (see PDCP_Unit_Stack.c) and Initialize (see Config_Unit.c)
    myUnit = CreateUnit();
    InitUnit(myUnit);
    
    // Create Data Channel (see PDCP_Unit_Stack.c) and Initialize (see Config_Unit.c)
    //   Data Channel is created as an input data channel capable of storing up to
    //   16 PDCP messages in its queue.  The Data Channel is initialized and will be
    //   assigned a channel index (in this case 1)
    in1 = AddDataChannel(myUnit, INPUT_DATA_CHANNEL_TRANSFER_TYPE, 16);
    InitDataChannel(in1,in1->channel_info.channelIndex);

//    // Create Data Channel (see PDCP_Unit_Stack.c) and Initialize (see Config_Unit.c)
//    //   Data Channel is created as an output data channel capable of storing up to
//    //   8 PDCP messages in its queue.  The Data Channel is initialized and will be
//    //   assigned a channel index (in this case 2)
//    out1 = AddDataChannel(myUnit, OUTPUT_DATA_CHANNEL_TRANSFER_TYPE, 8);
//    InitDataChannel(out1,out1->channel_info.channelIndex);
    
    // Configure microcontroller pins and modules
    _SWDTEN = 0;  // Disable Watchdog Timer
    CONFIG_MICRO();

    // Initialize and Start main microcontroller timer
    INIT_MAIN_TIMER();
    START_MAIN_TIMER();

    LED1_OFF();
    LED2_OFF();

    // Initialize the PDCP low-level hardware and buffer
    InitPDCPCommands();

    // Main Loop
    while(1)
    {
        UpdatePDCPCommandsStateMachine();
        UpdatePDCPStackStateMachine(myUnit);

        UpdateUnitFunctions();
        UpdateMotorControl();
    }

    return (EXIT_SUCCESS);
}


// Function used to specify control/actions by unit
void UpdateUnitFunctions(void)
{
    static unsigned int value_x[4];
    static unsigned int value_y[4];

    unsigned char incomingData[8];
    unsigned char messageLength;
    unsigned int  currentValue;
    unsigned int  currentValue2;
    
    unsigned int  microSeconds;
    unsigned int  outputIndex;

    // If there are any data messages in the Input Data Channel queue...
    if (IsInputDataChannelMessageAvailable(in1))
    {
        // Determine amount of data available is first available message
        messageLength = SizeOfInputDataChannelMessage(in1);

        // Acquire the data from the message
        GetDataFromInputDataChannelMessage(in1, incomingData);
        
        currentSetpoint1  = ((unsigned int)incomingData[1])*256 + incomingData[0];
        currentSetpoint2  = ((unsigned int)incomingData[3])*256 + incomingData[2];  // for Pitch/Roll joint module only
        dataFlag = 1;
        baseStep = baseStepConvert * (currentSetpoint1/100); //degree to step conversion, matlab numbers are 2 decimal point accurate.
        // Send Value to motorcontrol function here...
        //MotorControl(currentValue);   

    }
}



void PIDcalculation(void) 
{
    error = (baseStep - POSCNT);
    changeError = (error - lastError);
    totalError += error;
    pidTerm = (Kp * error) + (Ki * totalError) + (Kd * changeError);


    if (pidTerm > 0) {
        pidDir = 1;
        if (speed < 100) {
            speed = speed + inc;
        }
    } else {
        pidDir = -1;
        if (speed < 100) {
            speed = speed + inc;
        }
    }

    if (pidTerm < 0) {
        pidTerm = -1 * pidTerm;
    }

    if (pidTerm > 100) { //saturate the values to maximum pwm 
        pidTerm = 100;
        if (speed > 100) {
            speed = 100;
        }
    }
    if (lastPidDir != pidDir) {
        speed = 50;
    }
    lastPidDir = pidDir;
}

void UpdateMotorControl(void) //from main file code converting to function
{
    // control();
    if (HomePosition == 0) 
    {
        if (LIMSW_PIN == 1 && HomePosition == 0) 
        {
            SetPWM1DutyCycle(speed);
            dirtoggle = 0;
            
            if (speed < 100) {
                speed = speed + inc;
            }
            

        }
        else if (LIMSW_PIN == 0 && HomePosition == 0) 
        {
            IN1_OFF();
            IN2_OFF();
            HomePosition = 1;
            POSCNT = posCountOffset;
            LED1_TOGGLE();
            speed = 50;
        }

    } 
    else if (HomePosition == 1) 
    {
        baseStep = ((uint16_t) currentSetpoint1 * (uint16_t) baseStepConvert) + posCountOffset; //pos request in Degrees converting to steps
        if (baseStep == 0) {
            LED1_TOGGLE();
//            __delay32(300000);
        }
        if ((baseStep != POSCNT)&&(dataFlag == 1)) 
        {
            PIDcalculation();
            // printf("baseStep data PODCNT: %d %d %d\r\n", baseStep, data, POSCNT);
            if ((error > safeRange) || (error < -safeRange)) 
            {
                if (pidDir == 1) 
                {
                    //pitchdown
                    IN1_ON();
                    IN2_OFF();
                    SetPWM1DutyCycle(speed);

                    //printf("1 dir, baseStep, POSCNT, error, pidTerm %d %d %d %d\r\n", baseStep, POSCNT, error, speed);
                }
                else if (pidDir == -1) 
                {
                    //pitchup
                    IN1_OFF();
                    IN2_ON();
                    SetPWM1DutyCycle(speed);
                    //printf("-1 dir, baseStep, POSCNT, error, pidTerm %d %d %d %d\r\n", baseStep, POSCNT, error, speed);
                }
            } 
            else if ((error < safeRange) && (error > -safeRange)) 
            {
                IN1_ON();
                IN2_ON();
                //printf("Scorbot base at requested Degree - Error %d %d\n", data, error);
                dataFlag = 0;
                speed = 50;
            }
        }
    }
}

