/*
 * File:   Config_Unit.c
 * Author: yveslosier
 *
 * Created on July 4, 2014, 1:01 AM
 */

//---------------------------------------------------------------------------
// Functions and variables used to specify the specific attributes and
//   characterstics of the unit and its data channels
//---------------------------------------------------------------------------

#include <stdlib.h>
#include <string.h>

#include "PDCP_Unit_Commands.h"
#include "PDCP_Unit_Stack.h"
#include "Config_Unit.h"
#include "Config_Micro.h"

// Defining the descriptor for the unit and its data channels
unsigned char unitDescriptor[]               = "Scorbot Pitch Roll Joint Module Unit";
unsigned char input1ChannelDescriptor[]      = "Angular Setpoint Input Data Channel";
unsigned char output1ChannelDescriptor[]     = "Current Kinematics Output Data Channel";


// Initializing a Unit.  Most of the defined values can be located in Config_Unit.h
void InitUnit(UNIT* unit)
{
    unit->devInfo.VID               = VENDOR_ID;
    unit->devInfo.PID               = PRODUCT_ID;
    unit->devInfo.SN                = SERIAL_NUMBER;
    unit->devInfo.firmwareVersion   = FIRMWARE_VERSION;
    unit->devInfo.hardwareVersion   = HARDWARE_VERSION;
    unit->devInfo.type              = UNIT_TYPE;
    unit->devInfo.profile           = UNIT_PROFILE;
    unit->devInfo.descriptor.ptr    = unitDescriptor;
    unit->devInfo.descriptor.size   = sizeof(unitDescriptor);
    unit->devInfo.beaconInterval    = BEACON_INTERVAL;

    unit->devInfo.nodeId            = 0x01;    // assigned a temporary nodeId
    unit->busId                     = Can1Id;  // Specify that this unit is on a CAN bus
}

// Initializing the Data Channels.  Most of the defined values can be located in Config_Unit.h
void InitDataChannel(DATA_CHANNEL * newDataChannel, unsigned char ChannelIndex)
{
    INPUT_DATA_PARAMETERS  *inputParameters;
//    OUTPUT_DATA_PARAMETERS *outputParameters;

    SETPOINT_DATA *setpointParameters;
    //JOYSTICK_DATA *joystickParameters;

    switch (ChannelIndex)
    {
        // For the MEC Workshop lab, the first data channel was arbitrarily chosen to
        //   be an input data channel.  It is associated with the LED Bar Graph on the
        //   workshop board.
        case 1:

            newDataChannel->channel_info.type             = INPUT_CHANNEL_TYPE;
            newDataChannel->channel_info.profile          = INPUT_CHANNEL_PROFILE;
            newDataChannel->channel_info.descriptor.ptr   = input1ChannelDescriptor;
            newDataChannel->channel_info.descriptor.size  = sizeof(input1ChannelDescriptor);

            // Specifying the Structure Id associated with the data channel specific variables
            newDataChannel->dataChannelStructureId = SETPOINT_DATA_CHANNEL;

            // Pointer specifying location of the input data channel specific variables
            inputParameters = (INPUT_DATA_PARAMETERS*) newDataChannel->parameters;

            // Pointer specifying location of the Setpoint Data Channel specific variables
            setpointParameters = (SETPOINT_DATA *) calloc(1,sizeof(SETPOINT_DATA));
            inputParameters->parameters = setpointParameters;

            // Initializing channel specific data
            setpointParameters->sizeOfAveragingWindow = 1;  // Size of buffer used for moving average calculation

            // Initialize input data channel values... for Pitch/Roll Joint
            inputParameters->sourceVID =  1;
            inputParameters->sourcePID = 16;
            inputParameters->sourceSN  =  1;
            inputParameters->sourceCI  =  8;
            
            break;

//        // For the MEC Workshop lab, the second data channel was arbitrarily chosen to
//        //   be an output data channel.  It is associated with the x-axis of the joystick on the
//        //   workshop board.
//        case 2:
//
//            newDataChannel->channel_info.type             = OUTPUT_CHANNEL_TYPE;
//            newDataChannel->channel_info.profile          = OUTPUT_CHANNEL_PROFILE;
//            newDataChannel->channel_info.descriptor.ptr   = output1ChannelDescriptor;
//            newDataChannel->channel_info.descriptor.size  = sizeof(output1ChannelDescriptor);
//
//            // Specifying the Structure Id associated with the data channel specific variables
//            newDataChannel->dataChannelStructureId = JOYSTICK_DATA_CHANNEL;
//
//            // Pointer specifying location of the input data channel specific variables
//            outputParameters = (OUTPUT_DATA_PARAMETERS*) newDataChannel->parameters;
//
//            // Pointer specifying location of the Joystick Axis Data Channel specific variables
//            joystickParameters = (JOYSTICK_DATA *) calloc(1,sizeof(JOYSTICK_DATA));
//            outputParameters->parameters = joystickParameters;
//
//            // Initializing channel specific data
//            joystickParameters->sizeOfAveragingWindow = 1;  // Size of buffer used for moving average calculation
//
//            break;
//
//        // For the MEC Workshop lab, the third data channel was arbitrarily chosen to
//        //   be an output data channel.  It is associated with the y-axis of the joystick on the
//        //   workshop board.
//        case 3:
//
//            newDataChannel->channel_info.type             = OUTPUT_CHANNEL_TYPE;
//            newDataChannel->channel_info.profile          = OUTPUT_CHANNEL_PROFILE;
//            newDataChannel->channel_info.descriptor.ptr   = output2ChannelDescriptor;
//            newDataChannel->channel_info.descriptor.size  = sizeof(output2ChannelDescriptor);
//
//            // Specifying the Structure Id associated with the data channel specific variables
//            newDataChannel->dataChannelStructureId = JOYSTICK_DATA_CHANNEL;
//
//            // Pointer specifying location of the input data channel specific variables
//            outputParameters = (OUTPUT_DATA_PARAMETERS*) newDataChannel->parameters;
//
//            // Pointer specifying location of the Joystick Axis Data Channel specific variables
//            joystickParameters = (JOYSTICK_DATA *) calloc(1,sizeof(JOYSTICK_DATA));
//            outputParameters->parameters = joystickParameters;
//
//            // Initializing channel specific data
//            joystickParameters->sizeOfAveragingWindow = 1;  // Size of buffer used for moving average calculation
//
//            break;
        default:
            while(1) {} // Incorrect value used as Channel Index variable for this function call...

            break;
    }
}


// Function used to handle data channel specific variables
void ProcessDataChannelSpecificParameters(UNIT* unit, PDCPMESSAGE* currentPDCPMessage, void* parameters, unsigned char dataChannelStructureId, unsigned char functionCode)
{
    GET_UNIT_PARAMETER_COMMAND_MESSAGE * GDPC;
    SET_UNIT_PARAMETER_COMMAND_MESSAGE * SDPC;

    PDCPMESSAGE* currentTxMessage;

    unsigned char parameterData[4];
    unsigned int  parameterDataLength;

    SETPOINT_DATA* setpointParameters;
//    LED_DISPLAY* LEDParameters;
//    JOYSTICK_DATA* JOYSTICKParameters;

    switch (dataChannelStructureId)
    {
        case SETPOINT_DATA_CHANNEL:

            setpointParameters = (SETPOINT_DATA*)parameters;

            switch (functionCode)
            {
                case PDCP_COMMAND_GET_UNIT_PARAMETER:

                    GDPC = (GET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;

                    switch (GDPC->parameterId)
                    {
//                        case LED_DISPLAY_CURRENT_VALUE:
//
//                            parameterData[0]=(unsigned char)LEDParameters->data.value;
//                            parameterData[1]=(unsigned char)(LEDParameters->data.value>>8)&0xFF;
//                            parameterDataLength = 2;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//                            
//                            break;
//                        case LED_DISPLAY_SIZE_OF_AVERAGE_WINDOW:
//
//                            parameterData[0]=(unsigned char)LEDParameters->sizeOfAveragingWindow;
//                            parameterData[1]=(unsigned char)(LEDParameters->sizeOfAveragingWindow>>8)&0xFF;
//
//                            parameterDataLength = 2;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
                        default:
                            parameterDataLength = 0;

                            currentTxMessage = FindEmptyPdcpMessageLocation();
                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
                            SEND_PDCP_MESSAGE(currentTxMessage);
                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                            break;
                    }

                    break;
                case PDCP_COMMAND_SET_UNIT_PARAMETER:

                    SDPC = (SET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;

                    switch (SDPC->parameterId)
                    {
//                        case LED_DISPLAY_SIZE_OF_AVERAGE_WINDOW:
//
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//
//
//                            if ((((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0])>0)&&(((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0])<=MAX_AVERAGING_WINDOW_SIZE))
//                            {
//                                LEDParameters->sizeOfAveragingWindow = ((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0]);
//
//                                parameterData[0]=(unsigned char)LEDParameters->sizeOfAveragingWindow;
//                                parameterData[1]=(unsigned char)(LEDParameters->sizeOfAveragingWindow>>8)&0xFF;
//                                parameterDataLength = 2;
//
//                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
//                            }
//                            else
//                            {
//                                parameterData[0]=(unsigned char)LEDParameters->sizeOfAveragingWindow;
//                                parameterData[1]=(unsigned char)(LEDParameters->sizeOfAveragingWindow>>8)&0xFF;
//                                parameterDataLength = 2;
//
//                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
//                            }
//
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;

                        default:
                            parameterDataLength = 0;

                            currentTxMessage = FindEmptyPdcpMessageLocation();
                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                            CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
                            SEND_PDCP_MESSAGE(currentTxMessage);
                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                            break;
                    }

                    break;

                default:

                    currentTxMessage = FindEmptyPdcpMessageLocation();
                    RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
                    CREATE_UNKNOWN_FUNCTION_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId);
                    SEND_PDCP_MESSAGE(currentTxMessage);
                    AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);

                    break;
            }

            break;
//        case JOYSTICK_DATA_CHANNEL:
//
//            JOYSTICKParameters = (JOYSTICK_DATA*)parameters;
//
//            switch (functionCode)
//            {
//                case PDCP_COMMAND_GET_UNIT_PARAMETER:
//
//                    GDPC = (GET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;
//
//                    switch (GDPC->parameterId)
//                    {
//                        case JOYSTICK_CURRENT_VALUE:
//
//                            parameterData[0]=(unsigned char)JOYSTICKParameters->data.value;
//                            parameterData[1]=(unsigned char)(JOYSTICKParameters->data.value>>8)&0xFF;
//                            parameterDataLength = 2;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
//                        case JOYSTICK_SIZE_OF_AVERAGE_WINDOW:
//
//                            parameterData[0]=(unsigned char)JOYSTICKParameters->sizeOfAveragingWindow;
//                            parameterData[1]=(unsigned char)(JOYSTICKParameters->sizeOfAveragingWindow>>8)&0xFF;
//                            parameterDataLength = 2;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
//                        default:
//                            parameterDataLength = 0;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_GET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, GDPC->parameterId, GDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
//                    }
//
//                    break;
//                case PDCP_COMMAND_SET_UNIT_PARAMETER:
//
//                    SDPC = (SET_UNIT_PARAMETER_COMMAND_MESSAGE *)currentPDCPMessage->data;
//
//                    switch (SDPC->parameterId)
//                    {
//                        case JOYSTICK_SIZE_OF_AVERAGE_WINDOW:
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//
//                            if ((((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0])>=0)&&(((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0])<=MAX_AVERAGING_WINDOW_SIZE))
//                            {
//                                JOYSTICKParameters->sizeOfAveragingWindow = ((((unsigned int)SDPC->parameterData[1])<<8)+SDPC->parameterData[0]);
//
//                                parameterData[0]=(unsigned char)JOYSTICKParameters->sizeOfAveragingWindow;
//                                parameterData[1]=(unsigned char)(JOYSTICKParameters->sizeOfAveragingWindow>>8)&0xFF;
//                                parameterDataLength = 2;
//
//                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_SUCCESSFUL, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
//                            }
//                            else
//                            {
//                                parameterData[0]=(unsigned char)JOYSTICKParameters->sizeOfAveragingWindow;
//                                parameterData[1]=(unsigned char)(JOYSTICKParameters->sizeOfAveragingWindow>>8)&0xFF;
//                                parameterDataLength = 2;
//
//                                CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
//                            }
//
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
//                        default:
//                            parameterDataLength = 0;
//
//                            currentTxMessage = FindEmptyPdcpMessageLocation();
//                            RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                            CREATE_SET_UNIT_PARAMETER_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId, PDCP_RESPONSE_CODE_FAILURE, SDPC->parameterId, SDPC->channelIndex, parameterData, parameterDataLength);
//                            SEND_PDCP_MESSAGE(currentTxMessage);
//                            AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                            break;
//                    }
//
//                    break;
//                default:
//
//                    currentTxMessage = FindEmptyPdcpMessageLocation();
//                    RemovePdcpMessageFromEmptyPdcpMessageList(currentTxMessage);
//                    CREATE_UNKNOWN_FUNCTION_RESPONSE_MESSAGE(currentTxMessage, unit->busId, unit->devInfo.nodeId);
//                    SEND_PDCP_MESSAGE(currentTxMessage);
//                    AppendPdcpMessageToEmptyPdcpMessageList(currentTxMessage);
//
//                    break;
//            }
//
//            break;
        default:

            while(1) {} // only here if the datachannel structure has not been defined/assigned properly...

            break;
    }

}


// Note: This function is currently not being used for any variable in this demo
//        unit but was written to give a template for storing bulk data into a variable.
void StoreBulkDataIntoVariable(UNIT *unit)
{
    DATA_CHANNEL * currentDataChannel;

    INPUT_DATA_PARAMETERS  * inputParameters;
//    OUTPUT_DATA_PARAMETERS * outputParameters;

//    LED_DISPLAY   * LEDParameters;
//    JOYSTICK_DATA * JOYSTICKParameters;


    if (unit->bulkDataVars.Flag == 1)
    {
        if (unit->bulkDataVars.CI == UNIT_CHANNEL_INDEX)
        {

        }
        else
        {
            currentDataChannel = FindDataChannelByChannelIndex(unit, unit->bulkDataVars.CI);

            if (currentDataChannel->channel_info.transferType == INPUT_DATA_CHANNEL_TRANSFER_TYPE)
            {
                inputParameters = (INPUT_DATA_PARAMETERS*) currentDataChannel->parameters;
            }

            switch (currentDataChannel->dataChannelStructureId)
            {
//                // JUST A TEMPLATE IF A BULK DATA TRANSFER VARIABLE WAS IN A DATA CHANNEL STRUCTURE...
//                case LED_DISPLAY_DATA_CHANNEL:
//
//                    LEDParameters = (LED_DISPLAY *)inputParameters->parameters;
//
//                    switch (unit->bulkDataVars.ParamId)
//                    {
//                        case LED_DISPLAY_SPECIFIC_LED_MASK:
//
//                            //memcpy(LEDParameters->if_I_had_a_variable_it_would_be_here...,unit->bulkDataVars.Ptr,unit->bulkDataVars.Size);
//
//                            break;
//                        default:
//
//                            break;
//                    }
//
//                    break;
                default:

                    break;
            }
        }
    }
}


unsigned int UpdateSetpointVariables(DATA_CHANNEL* in1, unsigned int* incomingData)
{
    INPUT_DATA_PARAMETERS* inputParameters;
    SETPOINT_DATA* setpointParameters;

    inputParameters = (INPUT_DATA_PARAMETERS*)in1->parameters;
    setpointParameters = inputParameters->parameters;

//    setpointParameters->data.rawData[setpointParameters->data.idx] = incomingData[0];
//    setpointParameters->data.idx++;
//    if (setpointParameters->data.idx >= setpointParameters->sizeOfAveragingWindow) {setpointParameters->data.idx = 0;}
//
//    setpointParameters->data.rawData[setpointParameters->data.idx] = incomingData[1];
//    setpointParameters->data.idx++;
//    if (setpointParameters->data.idx >= setpointParameters->sizeOfAveragingWindow) {setpointParameters->data.idx = 0;}
//
//    setpointParameters->data.rawData[setpointParameters->data.idx] = incomingData[2];
//    setpointParameters->data.idx++;
//    if (setpointParameters->data.idx >= setpointParameters->sizeOfAveragingWindow) {setpointParameters->data.idx = 0;}
//
//    setpointParameters->data.rawData[setpointParameters->data.idx] = incomingData[3];
//    setpointParameters->data.idx++;
//    if (setpointParameters->data.idx >= setpointParameters->sizeOfAveragingWindow) {setpointParameters->data.idx = 0;}

//    UpdateAverageValue(setpointParameters);

    return setpointParameters->data.value;
}

void UpdateAverageValue(SETPOINT_DATA* setpointParameters)
{
    unsigned int i;
    unsigned long averageValue = 0;
    
    
    for (i=0; i<setpointParameters->sizeOfAveragingWindow; i++)
    {
        averageValue = averageValue + setpointParameters->data.rawData[i];
    }
    
    averageValue = averageValue / setpointParameters->sizeOfAveragingWindow;
    
    setpointParameters->data.value = (unsigned int)averageValue;
}




