/* 
 * File:   Config_Micro.h
 * Author: yveslosier
 *
 * Created on February 18, 2014, 9:59 PM
 */

#ifndef CONFIG_MICRO_H
#define	CONFIG_MICRO_H

#ifdef	__cplusplus
extern "C" {
#endif



#define MICROSTICK

#define FCY 16000000

#define CAN1_Enable_Pin  _LATB5
#define CAN1_Standby_Pin _LATB4
#define CAN2_Enable_Pin  _LATB5
#define CAN2_Standby_Pin _LATB4

#define Can1Id 1  // this defines the busId '1' as being the CAN1 Module...

#include "p33Fxxxx.h"

#include "Timer1.h"
#include "CAN2.h"
#include "I2C.h"
#include "ADC1.h"

#define Can1Id 1  // this defines the busId '1' as being the CAN Module...

// Define the pin connected to the onboard LED
#define LED1_PIN  _LATA0
#define LED2_PIN  _LATA1
    
#define ENABLE_PIN  _LATB14
    
#define IN1_PIN  _LATB12
#define IN2_PIN  _LATB13
#define IN3_PIN  _LATB3
#define IN4_PIN  _LATB15    
    
#define LIMSW_PIN _RA4 //Limitswitch


// Define specific functions needed by PDCP library
void Config_LED1_Pin(void);
void Config_LED2_Pin(void);

//Enable control
void ENABLE_ON(void);
void ENABLE_OFF(void);
void ENABLE_TOGGLE(void);

//IN1 control
void IN1_ON(void);
void IN1_OFF(void);
void IN1_TOGGLE(void);

//IN2 Control
void IN2_ON(void);
void IN2_OFF(void);
void IN2_TOGGLE(void);

//IN3 control
void IN3_ON(void);
void IN3_OFF(void);

//IN4 control
void IN4_ON(void);
void IN4_OFF(void);

//INPUT RA4
void LIMSW_HOLD(void);

void LED1_ON(void);
void LED1_OFF(void);
void LED1_TOGGLE(void);

void LED2_ON(void);
void LED2_OFF(void);
void LED2_TOGGLE(void);

void INIT_MAIN_TIMER(void);
void START_MAIN_TIMER(void);
void STOP_MAIN_TIMER(void);
unsigned long GET_CURRENT_TIME(void);
void CLEAR_ALL_INTERRUPTS(void);

void CONFIG_MICRO(void);


#ifndef NULL_POINTER
   #define NULL_POINTER 0
#endif



#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_UNIT_H */

